package ar.edu.unlp.lifia.capacitacion.domain.spy;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleIndividual;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleType;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spyState.NormalState;
import ar.edu.unlp.lifia.capacitacion.domain.spyState.SilenceRequest;
import ar.edu.unlp.lifia.capacitacion.domain.spyState.SpyState;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

public class Spy extends BaseEntity implements AccessRuleType, ReceiverType {

	private static final long serialVersionUID = 1L;
	private String username;
	private String password;
	@JsonManagedReference
	private SpyState state;
	private Rank rank;
	@JsonManagedReference
	private Role role;
	private Set<Message<?>> inbox;
	private Set<Message<?>> outbox;
	private Set<Message<?>> pendingInbox;
	private Set<Message<?>> pendingOutbox;
	private SilenceRequest silenceRequest;
	private String ipAddress;

	public Spy(String username, String password, Rank rank) {
		super();
		super.log(Spy.class).info("se crea clase: " + Spy.class.getName());
		this.username = username;
		this.password = password;
		this.state = new NormalState(this);
		this.inbox = new LinkedHashSet<Message<?>>();
		this.outbox = new LinkedHashSet<Message<?>>();
		this.pendingInbox = new LinkedHashSet<Message<?>>();
		this.pendingOutbox = new LinkedHashSet<Message<?>>();
		this.rank = rank;
		this.role = new Role(this, Roles.UNDEFINED);
	}

	public Spy() {
	}

	public String getUsername() {
		return username;
	}

	/* Silence Methods */
	public boolean requestSilenceWith(Spy aSpy) {
		return this.state.requestSilenceWith(aSpy);
	}

	public boolean receiveSilenceRequest(SilenceRequest silenceRequest) {
		return this.state.receiveSilenceRequest(silenceRequest);
	}

	public void acceptSilenceRequest(SilenceRequest silenceRequest) {
		// TODO: Refactor, el usuario conoce su propio silentRequest
		this.state.acceptSilenceRequest(silenceRequest);
	}

	public boolean acceptSilenceRequest() {
		// TODO: tiene que tener si o si un silentRequest
		return this.state.acceptSilenceRequest(this.getSilenceRequest());
	}

	public boolean disconnectSilenceRequest() {
		return this.state.disconnectSilenceRequest();
	}

	public void rejectSilenceRequest(SilenceRequest silenceRequest) {
		this.state.rejectSilenceRequest(silenceRequest);
	}

	public boolean rejectSilenceRequest() {
		return this.state.rejectSilenceRequest(this.getSilenceRequest());
	}

	public boolean rejectRequest() {
		return this.state.rejectRequest();
	}

	public void silenceWith(Spy aSpy, SilenceRequest silenceRequest) {
		state.silenceWith(aSpy);
	}

	/* END Silence Methods */

	/* Message Methods */
	public void sendMessage(Message<?> aMessage) {
		state.sendMessage(aMessage);
	}

	public void sendGroupMessage(Message<?> aMessage, Spy aSpy) {
		state.sendGroupMessage(aMessage, aSpy);
	}

	public void receiveMessage(Message<?> aMessage) {
		state.receiveMessage(aMessage);
	}

	public void readMessage(Message<?> aMessage) {

	}

	/* END Message Methods */

	public void setState(SpyState state) {
		this.state = state;
	}

	@JsonIgnore
	public int getInboxSize() {
		return inbox.size();
	}

	@JsonIgnore
	public int getOutboxSize() {
		return outbox.size();
	}

	@JsonIgnore
	public int getPendingInboxSize() {
		return pendingInbox.size();
	}

	@JsonIgnore
	public int getPendingOutboxSize() {
		return pendingOutbox.size();
	}

	public void dispatchPendings() {
		state.dispatchPendings(pendingInbox, pendingOutbox);

	}

	public void addOutbox(Message<?> aMessage) {
		this.outbox.add(aMessage);
	}

	public void addInbox(Message<?> aMessage) {
		this.inbox.add(aMessage);
	}

	public void addPendingOutbox(Message<?> aMessage) {
		this.pendingOutbox.add(aMessage);
	}

	public void addPendingInbox(Message<?> aMessage) {
		this.pendingInbox.add(aMessage);
	}

	public SilenceRequest getSilenceRequest() {
		return silenceRequest;
	}

	public void setSilenceRequest(SilenceRequest silenceRequest) {
		this.silenceRequest = silenceRequest;
	}
	@JsonIgnore
	public AccessRuleIndividual getAccessRule() {

		return new AccessRuleIndividual(this);
	}

	public boolean validateAgainst(Spy aSpy) {

		return this.equals(aSpy);
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@JsonIgnore
	public Rank getRank() {
		return rank;
	}

	public void setRank(Rank rank) {
		this.rank = rank;
	}

	// public Message<?>[] getInbox() {
	// ArrayList<Message<?>> arrayList = new ArrayList<Message<?>>();
	// return (Message<?>[]) inbox.toArray();
	// }

	@JsonIgnore
	public Set<Message<?>> getInbox() {
		return inbox;
	}

	public Set<Message<?>> getOutbox() {
		return outbox;
	}

	public Set<Message<?>> getPendingInbox() {
		return pendingInbox;
	}

	public Set<Message<?>> getPendingOutbox() {
		return pendingOutbox;
	}

	public void setInbox(Set<Message<?>> inbox) {
		this.inbox = inbox;
	}

	public void setOutbox(Set<Message<?>> outbox) {
		this.outbox = outbox;
	}

	public void setPendingInbox(Set<Message<?>> pendingInbox) {
		this.pendingInbox = pendingInbox;
	}

	public void setPendingOutbox(Set<Message<?>> pendingOutbox) {
		this.pendingOutbox = pendingOutbox;
	}

	@JsonIgnore
	public SpyState getState() {
		return state;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@JsonIgnore
	public Role getRole() {
		return role;
	}

	public void setRole(Role roles) {
		this.role = roles;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public boolean isVeteran() {
		return this.getRank().getRank().name() == Ranks.VETERAN.name();
	}

	@JsonIgnore
	public ArrayList<Message<?>> getLatestInbox(int count) {
		Message<?>[] aux = inbox.toArray(new Message<?>[inbox.size()]);
		ArrayList<Message<?>> list = new ArrayList<Message<?>>();

		for (int i = inbox.size() - count; i < aux.length; i++) {
			list.add(aux[i]);
		}
		return list;
	}

	@JsonIgnore
	public ArrayList<Message<?>> getLatestOutbox(int count) {
		Message<?>[] aux = outbox.toArray(new Message<?>[outbox.size()]);
		ArrayList<Message<?>> list = new ArrayList<Message<?>>();

		for (int i = outbox.size() - count; i < aux.length; i++) {
			list.add(aux[i]);
		}
		return list;
	}

}
