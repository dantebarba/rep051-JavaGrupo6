package ar.edu.unlp.lifia.capacitacion.dto;

import java.io.Serializable;
import java.util.Date;

public class BaseEntityDto implements Serializable {
	public BaseEntityDto() {
		
	}
	
	public BaseEntityDto(Long id2) {
		this.id = id2;
	}

	private static final long serialVersionUID = 1L;
	
	public Long id;
	
	public Date createdOn;
	
}
