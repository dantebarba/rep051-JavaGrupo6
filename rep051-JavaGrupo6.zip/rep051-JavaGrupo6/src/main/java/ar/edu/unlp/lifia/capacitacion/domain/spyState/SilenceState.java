package ar.edu.unlp.lifia.capacitacion.domain.spyState;

import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class SilenceState extends SpyState {

	private static final long serialVersionUID = 1L;

	public SilenceState() {
		super();
	}

	public SilenceState(Spy spy) {
		super();
		this.spy = spy;
	}

	@Override
	public boolean requestSilenceWith(Spy aSpy) {
		return false;
	}

	@Override
	public void silenceWith(Spy aSpy) {
		super.log(SilenceState.class).info("No implementado");
	}

	public void sendMessage(Message<?> aMessage) {
		if (this.spy.getSilenceRequest().isIn((Spy) aMessage.getReceiver())) {
			aMessage.getReceiver().receiveMessage(aMessage);
			this.spy.addOutbox(aMessage);
		} else {
			this.spy.addPendingOutbox(aMessage);
		}

	}

	@Override
	public void sendGroupMessage(Message<?> aMessage, Spy aSpy) {
		// retornamos false?
		super.log(SilenceState.class).fatal("no implementado");
	}

	public void receiveMessage(Message<?> aMessage) {
		if (this.spy.getSilenceRequest().isIn(aMessage.getSender())) {
			this.spy.addInbox(aMessage);
		} else {
			this.spy.addPendingInbox(aMessage);
		}

	}

	@Override
	public void readMessage(Message<?> aMessage) {

	}

	@Override
	public boolean rejectRequest() {
		return false;
	}

	public boolean disconnectSilenceRequest() {
		this.spy.getSilenceRequest().disconnect();
		return true;
	}

	@Override
	public String toString() {
		return "Silence State";
	}

}
