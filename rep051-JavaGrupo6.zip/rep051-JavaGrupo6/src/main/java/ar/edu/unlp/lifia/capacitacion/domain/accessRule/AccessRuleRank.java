package ar.edu.unlp.lifia.capacitacion.domain.accessRule;

import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;

public class AccessRuleRank extends AccessRule<Rank> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccessRuleRank(Rank rank) {
		super(rank);
	}

	@Override
	public AccessRuleType getTargetEntity() {
		return this.targetEntity;
	}

	@Override
	public void setTargetEntity(Rank t) {
		this.targetEntity = t;
	}

}
