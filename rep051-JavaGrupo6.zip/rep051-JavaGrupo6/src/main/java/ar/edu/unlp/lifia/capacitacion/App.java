package ar.edu.unlp.lifia.capacitacion;


/**
 * Hello world!
 * 
 */
// @SpringBootApplication
public class App {
	public static void main(String[] args) {
		// SpringApplication.run(App.class, args);
	}
}
