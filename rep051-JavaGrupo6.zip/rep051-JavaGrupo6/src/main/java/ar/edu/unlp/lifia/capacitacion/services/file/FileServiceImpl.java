package ar.edu.unlp.lifia.capacitacion.services.file;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import ar.edu.unlp.lifia.capacitacion.dao.file.FileDao;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;
import ar.edu.unlp.lifia.capacitacion.domain.file.Image;
import ar.edu.unlp.lifia.capacitacion.domain.file.Text;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.dto.CreatedImageFileDto;
import ar.edu.unlp.lifia.capacitacion.dto.CreatedTextFileDto;
import ar.edu.unlp.lifia.capacitacion.dto.FileDto;
import ar.edu.unlp.lifia.capacitacion.services.accessRule.AccessRuleService;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericServiceImpl;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

@Service
public class FileServiceImpl extends GenericServiceImpl<File<?>, FileDao>
		implements FileService {

	@Autowired
	public SpyService spyService;

	@Autowired
	public AccessRuleService accessRuleService;

	public Object accessFile(Long id, Long userId) throws Exception {
		Assert.notNull(id);
		File<?> file = this.findById(id);
		Assert.notNull(file, "Archivo no encontrado");
		Spy aSpy = this.spyService.findById(userId);
		Assert.notNull(aSpy, "Espia no encontrado");
		return file.getContent(aSpy);
	}

	public List<File<?>> listFilesByOwner(Long aSpy) {
		Assert.notNull(aSpy, "Se debe ingresar un usuario");
		List<File<?>> retrievedFiles = dao.findFileByOwner(aSpy);
		return retrievedFiles;
	}

	@Transactional(readOnly = true)
	public List<File<?>> listFilesForSpy(String username) {
		Spy aSpy = spyService.findByUsername(username);
		List<File<?>> resultFiles = dao.findAll();
		List<File<?>> resultList = this.checkAccessForFiles(aSpy, resultFiles);
		return resultList;
	}

	/**
	 * Retorna todos los archivos accesibles por aSpy, dentro de una lista de
	 * archivos dada. TODO Esto se deberia poder hacer con HQL, para mejor
	 * performance
	 * 
	 * @param aSpy
	 * @param resultFiles
	 * @return
	 */
	private List<File<?>> checkAccessForFiles(Spy aSpy,
			List<File<?>> resultFiles) {
		List<File<?>> resultList = new ArrayList<File<?>>();
		for (File<?> aFile : resultFiles) {
			if (aFile.validateAgainst(aSpy)) {
				resultList.add(aFile);
			}
		}
		return resultList;
	}

	/**
	 * @return the created Text file instance, with id.
	 */
	@Transactional
	public Text createTextFile(CreatedTextFileDto newFile) {

		createFileValidation(newFile);

		Spy anOwner = spyService.findById(newFile.owner.id);
		Assert.notNull(anOwner, "Usuario no encontrado");

		Text file = new Text();
		file.setOwner(anOwner);
		file.setFileName(newFile.name);
		file.setEncryptionStrategy(newFile.cryptoStrategy);
		file.setContent(newFile.content, anOwner);

		this.save(file);

		return file;
	}

	/**
	 * 
	 * @param newFile
	 * @return the created Image file instance (with id)
	 */
	@Transactional
	public Image createImageFile(CreatedImageFileDto newFile) {
		createFileValidation(newFile);

		Spy anOwner = spyService.findById(newFile.owner.id);
		Assert.notNull(anOwner, "Usuario no encontrado");

		Image file = new Image();
		file.setOwner(anOwner);
		file.setFileName(newFile.name);
		file.setEncryptionStrategy(newFile.cryptoStrategy);
		file.setContent(newFile.content, anOwner);
		file.setDescription(newFile.description);

		this.save(file);

		return file;
	}

	private void createFileValidation(FileDto newFile) {

		Assert.notNull(newFile);
		Assert.notNull(newFile.owner,
				"Se debe especificar un creador de archivo");
		Assert.notNull(newFile.content, "El archivo no tiene contenido");
		Assert.notNull(newFile.name, "El archivo no tiene nombre");
		Assert.notNull(newFile.owner.id,
				"Se debe especificar un creador de archivo");

	}

	public List<AccessRule<?>> listAccessRuleForFile(Long id, Long spyId)
			throws Exception {
		File<?> retrievedFile = this.findById(id);
		Spy anOwner = spyService.findById(spyId);
		List<AccessRule<?>> retrievedRules = retrievedFile
				.getAccessRulesForFile(anOwner);
		return retrievedRules;
	}

	@Transactional
	public void addAccessRuleToFile(Long fileId, AccessRule<?> newRule,
			Long userId) throws Exception {
		Assert.notNull(newRule, "Debe crear una nueva regla de acceso");

		File<?> file = this.findById(fileId);
		Assert.notNull(file, "Archivo no encontrado");

		Spy anOwner = spyService.findById(userId);
		file.addAccessRule(newRule, anOwner);
		dao.save(file);
	}

	@Transactional
	public boolean removeAccessRuleFromFile(Long accessRuleId, Long fileId,
			Long userId) throws Exception {
		Assert.notNull(accessRuleId);
		File<?> file = this.findById(fileId);

		Spy anOwner = spyService.findById(userId);

		AccessRule<?> rule = accessRuleService.findById(accessRuleId);
		Assert.notNull(rule,
				"No se pudo obtener la regla de acceso especificada");
		// TODO refactor feature envy.
		boolean result = file.deleteAccessRule(rule, anOwner);
		dao.save(file);
		return result;

	}

	@Transactional
	public void addIpAddressToFile(Long fileId, String ipAddress) {
		Assert.notNull(fileId,
				"La identificacion del archivo no puede ser nula");
		Assert.notNull(ipAddress, "La IP a agregar no puede ser nula");
		Assert.hasLength(ipAddress, "La IP debe tener longitud");

		File<?> file = dao.findById(fileId);
		file.addIp(ipAddress);
		dao.update(file);
	}

}