package ar.edu.unlp.lifia.capacitacion.services.group;

import ar.edu.unlp.lifia.capacitacion.dao.group.GroupDao;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericService;

public interface GroupService extends GenericService<Group, GroupDao> {
	/**
	 * Crea un grupo con los argumentos Name y Description. 
	 * @param name
	 * @param description
	 * @param sessionSpy spy loggeado
	 * 
	 */
	public Group createGroup(String name, String description, Long idSpy);
	
	/**
	 * Agrega un espia, si existe el espia, al grupo, si existe.
	 * @param groupId
	 * @param spyId
	 * @param role => habria que ver como llega esto ? 
	 */
	public boolean addSpy(long groupId, long spyId, Roles role);
	
	/**
	 * Elimina un espia del grupo, si existe el espia dentro del grupo.
	 * @param groupId
	 * @param spyId
	 */
	public boolean deleteSpyFrom(long groupId, long spyId);
	
	/**
	 * elimina el grupo si existe el id
	 * @param groupId
	 */
	public boolean deleteGroup(long groupId);
}
