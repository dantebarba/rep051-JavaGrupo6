package ar.edu.unlp.lifia.capacitacion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.services.group.GroupService;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

@RestController
@RequestMapping("/group")
public class GroupController {
	@Autowired
	private GroupService groupService;
	@Autowired
	private SpyService spyService;

	@RequestMapping(method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Long> createGroup(
			@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description,
			@RequestParam(value = "spy", required = true) Long idSpy) {

		Group aGroup = groupService.createGroup(name, description, idSpy);
		return new ResponseEntity<Long>(aGroup.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<Group> findGroup(
			@RequestParam(value = "id", required = true) Long id) {
		Group result = groupService.findById(id);
		if (result == null) {
			return new ResponseEntity<Group>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Group>(result, HttpStatus.OK);
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<List<Group>> findAll() {
		List<Group> result = groupService.findAll();
		if (result == null) {
			return new ResponseEntity<List<Group>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Group>>(result, HttpStatus.OK);
	}


	@RequestMapping(method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Boolean> deleteGroup(
			@RequestParam(value = "id", required = true) Long id) {
		try {
			groupService.deleteGroup(id);
			return new ResponseEntity<Boolean>(true, HttpStatus.GONE);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.NOT_FOUND);
		}
	}


}