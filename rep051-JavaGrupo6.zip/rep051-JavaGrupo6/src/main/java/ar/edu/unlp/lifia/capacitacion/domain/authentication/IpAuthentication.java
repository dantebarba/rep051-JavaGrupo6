package ar.edu.unlp.lifia.capacitacion.domain.authentication;

public class IpAuthentication {
	private Long idIpAuthentication;

}
