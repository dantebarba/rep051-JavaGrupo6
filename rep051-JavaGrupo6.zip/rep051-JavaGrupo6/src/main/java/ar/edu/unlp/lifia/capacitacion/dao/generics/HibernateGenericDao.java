package ar.edu.unlp.lifia.capacitacion.dao.generics;

import java.io.Serializable;
import java.util.List;

import org.hibernate.FlushMode;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

/* De esta clase deberian Heredar todos los DAO que implementamos.
 * 
 * Ejemplo de uso ->
 *  PersonDao extends HibernateGenericDao<PersonModel> implements PersonRepository
 *  hay que agregarle @Repository a las clases Que instancian HibernateGenericDao
 *  
 * */

@Repository
public abstract class HibernateGenericDao<T> extends HibernateDaoSupport
		implements GenericRepository<T> {

	/* Podria ser AOP para todos los que tienen DAO al final */
	@Autowired
	protected HibernateGenericDao(SessionFactory s) {
		setSessionFactory(s);
	}

	public HibernateGenericDao() {
		
	}

	protected Class<T> persistentClass = getDomainClass();

	public abstract Class<T> getDomainClass();

	public Serializable save(final T entity) {
		return getHibernateTemplate().save(entity);
	}

	public void delete(final T entity) {
		getHibernateTemplate().delete(entity);
	}

	public void deleteById(final Long id) {
		Object obj = getHibernateTemplate().get(this.persistentClass, id);
		getHibernateTemplate().delete(obj);
	}

	public void update(final T entity) {
		getHibernateTemplate().update(entity);
	}

	public void saveOrUpdate(final T entity) {
		getHibernateTemplate().saveOrUpdate(entity);
	}

	public T findById(final Serializable id) {
		return getHibernateTemplate().get(this.persistentClass, id);
	}

	@SuppressWarnings("unchecked")
	public List<T> findAll() {
		return (List<T>) getHibernateTemplate().findByCriteria(
				DetachedCriteria.forClass(getDomainClass()));
	}

	public void deleteById(final Serializable id) {
		T obj = this.findById(id);
		getHibernateTemplate().delete(obj);
	}

	public int countAll() {
		return (Integer) getHibernateTemplate().findByCriteria(
				DetachedCriteria.forClass(getDomainClass())).size();
	}

	public List<T> findByExample(final T exampleObject) {
		return getHibernateTemplate().findByExample(exampleObject);

	}
	
	public void flush() {
		getHibernateTemplate().flush();
	}

	/*
	 * protected Criteria createCriteria() { return
	 * this.getSession().createCriteria(this.getDomainClass()); }
	 */
}
