package ar.edu.unlp.lifia.capacitacion.domain.file;

import ar.edu.unlp.lifia.capacitacion.dto.CreatedImageFileDto;

/**
 * 
 * {@link Archivo} de tipo Imagen. La imagen puede contener una miniatura para
 * dispositivos móviles.
 * 
 */
public class Image extends File<String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private byte[] thumbnail;


	public byte[] getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(byte[] thumbnail) {
		this.thumbnail = thumbnail;
	}
	
	@Override
	protected String encrypt(String content) {
		return this.getEncryptionStrategy().encrypt(content);
	}
	
	@Override
	protected String decrypt(String content) {
		return this.getEncryptionStrategy().decrypt(content);
	}
	
	
}
