package ar.edu.unlp.lifia.capacitacion.domain.cryptography;

import org.jasypt.util.text.TextEncryptor;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;

/**
 * 
 * Simple Cryptography using Jasypt.
 * 
 * @see http://www.jasypt.org/
 * 
 */
public abstract class Cryptography extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Un password para el encryptador.
	private String encryptorPassword;

	public Cryptography() {
		// FIXME @dbarba aca se debe generar un password random
		this.encryptorPassword = "RandomStringGeneratedPasswd";

	}

	public Cryptography(String password) {
		this.encryptorPassword = password;
	}

	abstract TextEncryptor getTextEncryptor();

	public String encrypt(String textToEncrypt) {
		return this.getTextEncryptor().encrypt(textToEncrypt);
	}

	public String decrypt(String encryptedText) {
		return this.getTextEncryptor().decrypt(encryptedText);
	}

	protected String getEncryptorPassword() {
		return encryptorPassword;
	}
	
	protected void setEncryptorPassword(String passwd) {
		this.encryptorPassword = passwd;
	}

	public static Cryptography fromString(String cryptoType) {
		switch (cryptoType) {
			case "basic":
				return new BasicEncryption();
			case "strong":
				return new AdvancedEncryption();
			default:
				return new BasicEncryption();
		}
	}

}
