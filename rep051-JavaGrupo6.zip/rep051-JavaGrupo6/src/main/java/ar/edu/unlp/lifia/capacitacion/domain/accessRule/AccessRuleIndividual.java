package ar.edu.unlp.lifia.capacitacion.domain.accessRule;

import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class AccessRuleIndividual extends AccessRule<Spy> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccessRuleIndividual(Spy spy) {
		super(spy);
	}

	@Override
	public AccessRuleType getTargetEntity() {
		return this.targetEntity;
	}

	@Override
	public void setTargetEntity(Spy t) {
		this.targetEntity = t;
	}

}
