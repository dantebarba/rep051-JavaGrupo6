package ar.edu.unlp.lifia.capacitacion.services.group;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import ar.edu.unlp.lifia.capacitacion.dao.group.GroupDao;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericServiceImpl;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

@Service
public class GroupServiceImpl extends GenericServiceImpl<Group, GroupDao>
		implements GroupService {

	@Autowired
	SpyService spyService;

	@Override
	@Transactional
	public Group createGroup(String name, String description, Long idSpy) {
		Spy sessionSpy = spyService.findById(idSpy);	
		Assert.isTrue(sessionSpy.isVeteran());
			
			Group group = new Group(sessionSpy, name, description);

			this.save(group);
			
			return this.findById(group.id);
	}

	@Override
	public boolean addSpy(long groupId, long spyId, Roles role) {
			Spy spy = spyService.findById(spyId);
			Assert.notNull(spy, "No existe el espía");

			Group group = this.findById(groupId);
			Assert.notNull(group, "No Existe el grupo");

			boolean added = group.addSpy(spy, role);
			this.update(group);
			
			return added;
	}

	@Override
	public boolean deleteSpyFrom(long groupId, long spyId) {
			Spy spy = spyService.findById(spyId);
			Assert.notNull(spy, "No existe el espia");

			Group group = this.findById(groupId);
			Assert.notNull(group, "No Existe el grupo");

			boolean deleted = group.deleteSpy(spy);

			this.update(group);
			return deleted;
	}

	@Override
	public boolean deleteGroup(long groupId) {
		Group group = this.findById(groupId);

		Assert.notNull(group, "El grupo deberia existir");
		
		dao.deleteById(groupId);

		return true;
	}
}
