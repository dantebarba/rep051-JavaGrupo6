package ar.edu.unlp.lifia.capacitacion.services.file;

import java.util.List;

import ar.edu.unlp.lifia.capacitacion.dao.file.FileDao;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;
import ar.edu.unlp.lifia.capacitacion.domain.file.Image;
import ar.edu.unlp.lifia.capacitacion.domain.file.Text;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.dto.CreatedImageFileDto;
import ar.edu.unlp.lifia.capacitacion.dto.CreatedTextFileDto;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericService;

public interface FileService extends GenericService<File<?>, FileDao> {

	Object accessFile(Long fileId, Long userId) throws Exception;

	List<File<?>> listFilesForSpy(String username);
	
	Text createTextFile(CreatedTextFileDto newFile);
	
	Image createImageFile(CreatedImageFileDto newFile);
	
	List<AccessRule<?>> listAccessRuleForFile(Long id, Long spyId) throws Exception;
	
	void addAccessRuleToFile(Long fileId, AccessRule<?> newRule,
			Long userId) throws Exception;
	
	boolean removeAccessRuleFromFile(Long accessRuleId, Long fileId,
			Long userId) throws Exception;
	
	void addIpAddressToFile(Long fileId, String ipAddress);

	List<File<?>> listFilesByOwner(Long spy);

}
