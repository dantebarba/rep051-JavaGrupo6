package ar.edu.unlp.lifia.capacitacion.dto;

import ar.edu.unlp.lifia.capacitacion.domain.file.File;

public class CreatedTextFileDto extends FileDto {

	public CreatedTextFileDto() {
		
	}
	
	public CreatedTextFileDto(File<?> aFile) {
		super(aFile);
	}

	private static final long serialVersionUID = 1L;
	
	
	
	
	

}
