package ar.edu.unlp.lifia.capacitacion.dao.group;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ar.edu.unlp.lifia.capacitacion.dao.generics.HibernateGenericDao;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;

@Repository
public class GroupDaoImpl extends HibernateGenericDao<Group> implements
		GroupDao {

	@Autowired
	public GroupDaoImpl(SessionFactory s) {
		super(s);
	}

	@Override
	public Class<Group> getDomainClass() {

		return Group.class;
	}

}
