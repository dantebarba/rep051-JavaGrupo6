package ar.edu.unlp.lifia.capacitacion.domain.accessRule;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public abstract class AccessRule<T> extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/* este metodo debe llamar al de su Tipo correspondiente */
	public T targetEntity;
	
	public AccessRule() {
		
	}

	public AccessRule(T t) {
		this.setTargetEntity(t);
	}

	public boolean validateAgainst(Spy aSpy) {
		return (this.getTargetEntity()).validateAgainst(aSpy);
	}

	public abstract AccessRuleType getTargetEntity();
	
	public abstract void setTargetEntity(T t);

}
