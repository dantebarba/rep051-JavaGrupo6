package ar.edu.unlp.lifia.capacitacion.dao.file;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.GenericTypeResolver;
import org.springframework.stereotype.Repository;

import ar.edu.unlp.lifia.capacitacion.dao.generics.HibernateGenericDao;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;

@Repository
public class FileDaoImpl extends HibernateGenericDao<File<?>> implements FileDao {

	@Autowired
	protected FileDaoImpl(SessionFactory s) {
		super(s);
	}
	
	public Class<File<?>> getClazz() {
	     return (Class<File<?>>) GenericTypeResolver.resolveTypeArgument(getClass(), HibernateGenericDao.class);
	}
	// TODO this should be criterion
	public List<File<?>> findFileByOwner(Long spyId) {
		
		Session session = getHibernateTemplate().getSessionFactory()
				.openSession();
		String queryString = "from File f join fetch f.owner where f.owner.id = :spyId ";
		List<File<?>> result = (List<File<?>>) session.createQuery(queryString).setLong("spyId", spyId).list();
		return result;
	}

	@Override
	public Class<File<?>> getDomainClass() {
		return this.getClazz();
	}


}
