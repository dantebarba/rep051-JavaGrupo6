package ar.edu.unlp.lifia.capacitacion.domain.spyState;

import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class NormalState extends SpyState {

	private static final long serialVersionUID = 1L;

	public NormalState() {
		super();
	}
	
	public NormalState(Spy spy) {
		super();
		this.spy = spy;
		this.spy.setSilenceRequest(null);

	}

	public boolean requestSilenceWith(Spy aSpy) {
		if (aSpy.receiveSilenceRequest(new SilenceRequest(spy))) {
			this.spy.setState(new PendingState(this.spy));
			this.spy.setSilenceRequest(aSpy.getSilenceRequest());
			return true;
		}
		return false;
	}

	@Override
	public boolean receiveSilenceRequest(SilenceRequest silenceRequest) {
		if (this.spy.getSilenceRequest() == null) {
			this.spy.setSilenceRequest(silenceRequest);
			return true;
		}
		return false;
	}

	public boolean acceptSilenceRequest(SilenceRequest silenceRequest) {
		// corroborar
		silenceRequest.acceptRequestWith(this.spy);
		return true;
	}

	public boolean rejectSilenceRequest(SilenceRequest silenceRequest) {
		return silenceRequest.rejectRequestWith();
	}

	public void silenceWith(Spy aSpy) {
		this.spy.setState(new SilenceState(this.spy));
	}

	public void sendMessage(Message<?> aMessage) {
		aMessage.getReceiver().receiveMessage(aMessage);
		this.spy.addOutbox(aMessage);
	}

	public void sendGroupMessage(Message<?> aMessage, Group aGroup) {
		aGroup.receiveMessage(aMessage);
		this.spy.addOutbox(aMessage);
	}

	public void receiveMessage(Message<?> aMessage) {
		this.spy.addInbox(aMessage);
	}

	public void readMessage(Message<?> aMessage) {

	}

	public boolean rejectRequest() {
		return false;
	}

	@Override
	public void sendGroupMessage(Message<?> aMessage, Spy aSpy) {

	}
	
	@Override
	public String toString() {
		return "Normal State";
	}

}
