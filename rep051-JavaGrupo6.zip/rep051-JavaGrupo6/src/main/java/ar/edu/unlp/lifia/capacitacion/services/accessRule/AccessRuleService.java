package ar.edu.unlp.lifia.capacitacion.services.accessRule;

import ar.edu.unlp.lifia.capacitacion.dao.accessRule.AccessRuleDao;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericService;

public interface AccessRuleService extends GenericService<AccessRule, AccessRuleDao> {
	
}
