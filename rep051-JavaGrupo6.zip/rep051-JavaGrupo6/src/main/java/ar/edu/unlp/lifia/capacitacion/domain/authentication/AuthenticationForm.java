package ar.edu.unlp.lifia.capacitacion.domain.authentication;

public class AuthenticationForm {
	private Long idAuthenticationForm;

}
