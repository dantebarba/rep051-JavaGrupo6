package ar.edu.unlp.lifia.capacitacion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.unlp.lifia.capacitacion.domain.message.GroupMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.dto.IndividualMessageDto;
import ar.edu.unlp.lifia.capacitacion.services.message.MessageService;

@RestController
@RequestMapping("/message")
public class MessageController {
	@Autowired
	private MessageService messageService;

	@RequestMapping(value = "/individual",method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Long> sendIndividualMessage(
			@RequestParam(value = "idSender", required = true) Long idSender,
			@RequestParam(value = "idReceiver", required = true) Long idReceiver,
			@RequestParam(value = "content", required = true) String content) {

		IndividualMessage aMessage = messageService.sendIndividualMessage(idSender, idReceiver, content);
		return new ResponseEntity<Long>(aMessage.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/group",method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Long> sendGroupMessage(
			@RequestParam(value = "idSender", required = true) Long idSender,
			@RequestParam(value = "idReceiver", required = true) Long idReceiver,
			@RequestParam(value = "content", required = true) String content) {

		GroupMessage aMessage = messageService.sendGroupMessage(idSender, idReceiver, content);
		return new ResponseEntity<Long>(aMessage.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/individual", method = RequestMethod.GET)
	public @ResponseBody
	ResponseEntity<IndividualMessageDto> findIndividualMessage(
			@RequestParam(value = "id", required = true) Long id) {
		IndividualMessage aMessage = (IndividualMessage) messageService.findById(id);
		if (aMessage == null) {
			return new ResponseEntity<IndividualMessageDto>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<IndividualMessageDto>(new IndividualMessageDto(aMessage), HttpStatus.OK);
	}

	@RequestMapping(value = "/group", method = RequestMethod.GET)
	public @ResponseBody
	ResponseEntity<Long> findGroupMessage(
			@RequestParam(value = "id", required = true) Long id) {
		GroupMessage aMessage = (GroupMessage) messageService.findById(id);
		if (aMessage == null) {
			return new ResponseEntity<Long>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Long>(aMessage.getId(), HttpStatus.OK);
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<List<Message<?>>> findAll() {
		List<Message<?>> result = messageService.findAll();
		if (result == null) {
			return new ResponseEntity<List<Message<?>>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Message<?>>>(result, HttpStatus.OK);
	}




}