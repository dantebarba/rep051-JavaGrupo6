package ar.edu.unlp.lifia.capacitacion.dto;

import java.util.Set;

import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Boss;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class GroupDto extends BaseEntityDto {
	
	public GroupDto(Group group) {
		super(group.getId());
		spies = group.getSpies();
		description = group.getDescription();
		name = group.getName();
		
	}

	public GroupDto(Long ownerId) {
		super(ownerId);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Set<Role> spies;
	public String name;
	public String description;

}
