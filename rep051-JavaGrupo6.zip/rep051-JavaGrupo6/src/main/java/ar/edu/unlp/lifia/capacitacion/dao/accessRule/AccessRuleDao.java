package ar.edu.unlp.lifia.capacitacion.dao.accessRule;

import ar.edu.unlp.lifia.capacitacion.dao.generics.GenericRepository;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;

public interface AccessRuleDao extends GenericRepository<AccessRule> {

}
