package ar.edu.unlp.lifia.capacitacion.domain.message;

import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class IndividualMessage extends Message<Spy> {
	private static final long serialVersionUID = 1L;

	public IndividualMessage(Spy sender, Spy receiver, String content) {
		super(sender, receiver, content);
	}

	public IndividualMessage() {
		super();
	}
}
