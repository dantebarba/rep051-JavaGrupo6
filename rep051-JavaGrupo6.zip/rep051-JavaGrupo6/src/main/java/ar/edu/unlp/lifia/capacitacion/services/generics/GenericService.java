package ar.edu.unlp.lifia.capacitacion.services.generics;

import java.io.Serializable;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.lifia.capacitacion.dao.generics.GenericRepository;

public interface GenericService<T, G extends GenericRepository<T>> {

	List<T> findAll();

	T findById(final Serializable id);
	
	@Transactional
	void save(final T entity);
	
	@Transactional
	void update(final T entity);

}
