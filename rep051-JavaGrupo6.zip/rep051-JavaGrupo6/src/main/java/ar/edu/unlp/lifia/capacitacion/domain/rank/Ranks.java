package ar.edu.unlp.lifia.capacitacion.domain.rank;

public enum Ranks {
	NOVICE, VETERAN, COUNTERINTELLIGENCE; //Novato, Veterano, Contrainteligente
}
