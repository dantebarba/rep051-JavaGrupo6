package ar.edu.unlp.lifia.capacitacion.dao.spy;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ar.edu.unlp.lifia.capacitacion.dao.generics.HibernateGenericDao;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

@Repository
public class SpyDaoImpl extends HibernateGenericDao<Spy> implements SpyDao {

	@Autowired
	public SpyDaoImpl(SessionFactory s) {
		super(s);
	}

	public Spy findByUsername(String username) {
		Spy exampleInstance = new Spy();
		exampleInstance.setUsername(username);
		List<Spy> result = this.findByExample(exampleInstance);
		return ((result.isEmpty()) ? null : result.get(0));
	}

	@Override
	public Class<Spy> getDomainClass() {
		return Spy.class;
	}

}
