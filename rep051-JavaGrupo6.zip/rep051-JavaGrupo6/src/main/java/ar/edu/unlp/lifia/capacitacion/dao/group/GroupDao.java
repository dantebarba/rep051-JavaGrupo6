package ar.edu.unlp.lifia.capacitacion.dao.group;

import ar.edu.unlp.lifia.capacitacion.dao.generics.GenericRepository;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;

public interface GroupDao extends GenericRepository<Group> {

}
