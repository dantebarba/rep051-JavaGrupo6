package ar.edu.unlp.lifia.capacitacion.services.spy;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import ar.edu.unlp.lifia.capacitacion.dao.spy.SpyDao;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericServiceImpl;

@Service
@Transactional
public class SpyServiceImpl extends GenericServiceImpl<Spy, SpyDao> implements
		SpyService {
	/**
	 * 
	 */
	public Spy findByUsername(String username) {
		Assert.notNull(username, "El nombre de usuario no puede estar vacio");
		Assert.hasLength(username, "El nombre de usuario no puede estar vacio");
		Spy result = dao.findByUsername(username);
		return result;
	}

	/**
	 * 
	 * @param username
	 * @param password
	 * @param rank
	 * @return
	 */
	@Transactional
	public Spy createSpy(String username, String password, Rank rank) {
		// session actual usuario loggeado es admin
		Assert.hasLength(username);
		Assert.hasLength(password);
		Assert.isInstanceOf(Rank.class, rank); // para que no venga null?
		Assert.isTrue(rank != null);

		Spy spy = new Spy(username, password, rank);

		this.save(spy);

		return spy;
	}

	/**
	 * 
	 * @param spyId
	 */
	@Transactional
	public void deleteSpy(Long spyId) {
		// session actual loggeado es admin
		Assert.isTrue(this.findById(spyId) != null);
		dao.deleteById(spyId);
	}

	/**
	 * 
	 * @param spyId
	 * @param username
	 * @param password
	 * @param rank
	 * @param role
	 */
	@Transactional
	public void modifySpy(Long spyId, String username, String password,
			Rank rank, Role role) {
		// session actual loggeado es admin
		Spy spy = this.findById(spyId);
		Assert.notNull(spy);
		Assert.hasLength(username);
		Assert.hasLength(password);
		Assert.notNull(rank);
		Assert.notNull(role);

		spy.setUsername(username);
		spy.setPassword(password);
		spy.setRank(rank);
		spy.setRole(role);
	}
	
	public List<Message<?>> getLatestMessages(Long spyId, int count)
	{
		Spy spy = this.findById(spyId);
		Assert.notNull(spy);
		
		return spy.getLatestInbox(count);
	}

	@Override
	@Transactional
	public boolean requestSilenceWith(Long senderId, Long receptorId) {
		
		/*TODO: falta saber si la recibe o no!*/
		
		Assert.notNull(senderId, "No se ha enviado ningun emisor");
		Assert.notNull(receptorId, "No se ha enviado ningun receptor");
				
		Spy sender = this.findById(senderId);
		Assert.notNull(sender, "No se encuentra el emisor en la base de datos");
		
		Spy receptor = this.findById(receptorId);
		Assert.notNull(receptor, "No se encuentra el receptor en la base de datos");
		
		boolean couldSendRequest = sender.requestSilenceWith(receptor);
		
		this.update(sender);
		this.update(receptor);
		//TODO: falta algun save?messageSave?
		
		return couldSendRequest;
	}

	@Override
	@Transactional
	public boolean acceptRequestWith(Long receptorId, Long senderId) {
		
		Spy receptor = this.findById(receptorId);
		Assert.notNull(receptor);
				
		boolean couldAcceptRequest = receptor.acceptSilenceRequest();
		
		this.update(receptor); // flush?
		
		return couldAcceptRequest;
	}

	@Override
	@Transactional
	public boolean disconnectSilenceRequest(Long spyId) {
		
		Spy spy = this.findById(spyId);	
		Assert.notNull(spy);
		
		Assert.notNull(spy.getSilenceRequest());
		
		boolean couldDisconnect = spy.disconnectSilenceRequest();
		
		this.update(spy);
		
		return couldDisconnect;
		
	}

	@Override
	@Transactional
	public boolean rejectSilenceRequest(Long spyId) {
		Spy spy = this.findById(spyId);
		Assert.notNull(spy);
		Assert.notNull(spy.getSilenceRequest());
		
		
		boolean couldReject = spy.rejectSilenceRequest();
		
		this.update(spy);
		
		return couldReject;
	}


}
