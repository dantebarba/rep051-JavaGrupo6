package ar.edu.unlp.lifia.capacitacion.domain.message;

import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class GroupMessage extends Message<Group> {
	
	public GroupMessage() {
		super();
	}
	
	public GroupMessage(Spy sender, Group receiver, String content) {
		// TODO  constructor stub
		super(sender, receiver, content);
	}
	
	

}
