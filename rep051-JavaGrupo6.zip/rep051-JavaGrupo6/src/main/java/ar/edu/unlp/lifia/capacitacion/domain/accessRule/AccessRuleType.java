package ar.edu.unlp.lifia.capacitacion.domain.accessRule;

import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

/**
 * está interfaz la deben implementar las clases que tienen asociado un permiso
 *
 */
public interface AccessRuleType {
	/* Devuelve la respectiva regla que la reconoce */
	public AccessRule getAccessRule();

	/*
	 * cada uno debe saber reconocer si el espía està asociado EJEMPLO: si es
	 * spy, deberìa ser el mismo. si es Rank, el spy deberia tener ese rank
	 */
	public boolean validateAgainst(Spy aSpy);
}
