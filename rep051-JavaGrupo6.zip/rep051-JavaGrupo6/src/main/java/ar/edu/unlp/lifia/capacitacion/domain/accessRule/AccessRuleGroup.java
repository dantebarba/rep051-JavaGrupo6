package ar.edu.unlp.lifia.capacitacion.domain.accessRule;

import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;

public class AccessRuleGroup extends AccessRule<Group> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccessRuleGroup(Group group) {
		super(group);
	}

	@Override
	public AccessRuleType getTargetEntity() {
		return this.targetEntity;
	}

	@Override
	public void setTargetEntity(Group t) {
		this.targetEntity = t;
	}



}
