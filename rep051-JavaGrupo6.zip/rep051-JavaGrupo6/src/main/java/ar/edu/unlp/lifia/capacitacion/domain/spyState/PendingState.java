package ar.edu.unlp.lifia.capacitacion.domain.spyState;

import sun.util.logging.resources.logging;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class PendingState extends SpyState {
	private static final long serialVersionUID = 1L;

	public PendingState(Spy spy) {
		super();
		this.spy = spy;
	}

	public boolean requestSilenceWith(Spy aSpy) {
		return aSpy.receiveSilenceRequest(new SilenceRequest(spy));
	}

	public boolean acceptSilenceRequest(SilenceRequest silenceRequest) {
		// corroborar
		silenceRequest.acceptRequestWith(this.spy);
		return true;
	}

	public boolean rejectSilenceRequest(SilenceRequest silenceRequest) {
		return silenceRequest.rejectRequestWith();

	}

	public void silenceWith(Spy aSpy) {
		this.spy.setState(new SilenceState(this.spy));
	}

	public void sendMessage(Message<?> aMessage) {
		this.spy.addPendingOutbox(aMessage);
	}

	public void sendGroupMessage(Message<?> aMessage, Spy aSpy) {
		super.log(PendingState.class).fatal("no implementado");
		// que hacemos? envia el mensaje o lo encola en otro lista?
	}

	public void receiveMessage(Message<?> aMessage) {
		this.spy.addPendingInbox(aMessage);
	}

	public void readMessage(Message<?> aMessage) {

	}

	public boolean rejectRequest() {
		this.spy.setState(new NormalState(this.spy));
		this.spy.dispatchPendings();
		return true;
	}

}
