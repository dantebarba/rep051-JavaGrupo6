package ar.edu.unlp.lifia.capacitacion.domain.cryptography;

import org.jasypt.util.text.BasicTextEncryptor;
import org.jasypt.util.text.TextEncryptor;

public class BasicEncryption extends Cryptography {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
	
	public BasicEncryption() {
		super();
		textEncryptor.setPassword(this.getEncryptorPassword());
	}
	
	public BasicEncryption(String passwd) {
		super(passwd);
		textEncryptor.setPassword(this.getEncryptorPassword());
	}

	@Override
	TextEncryptor getTextEncryptor() {
		return this.textEncryptor;
	}

	void setTextEncryptor(BasicTextEncryptor encryptor) {
		this.textEncryptor = encryptor;
	}
	
}
