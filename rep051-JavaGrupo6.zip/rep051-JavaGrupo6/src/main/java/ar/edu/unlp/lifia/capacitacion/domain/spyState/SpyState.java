package ar.edu.unlp.lifia.capacitacion.domain.spyState;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

public abstract class SpyState extends BaseEntity {

	private static final long serialVersionUID = 1L;
	@JsonBackReference
	protected Spy spy;

	/**
	 * Crea una solicitu de cono de silencio.
	 * 
	 * @param aSpy
	 * @return si 
	 */
	public abstract boolean requestSilenceWith(Spy aSpy);

	/**
	 * 
	 * @param silenceRequest
	 * @return
	 */
	public boolean receiveSilenceRequest(SilenceRequest silenceRequest) {
		return false;
	};

	public abstract void silenceWith(Spy aSpy);

	public abstract void sendMessage(Message<?> aMessage);

	public abstract void sendGroupMessage(Message<?> aMessage, Spy aSpy);

	public abstract void receiveMessage(Message<?> aMessage);

	public abstract void readMessage(Message<?> aMessage);

	public boolean acceptSilenceRequest(SilenceRequest silenceRequest) {
		return false;
	}

	/**
	 * 
	 * @return true si pudo desconectar, false si no pudo desconectar
	 */
	public boolean disconnectSilenceRequest() {
		return false;
	}

	/**
	 * 
	 * @param silenceRequest
	 * @return retorna false si no puede rechazar
	 */
	public boolean rejectSilenceRequest(SilenceRequest silenceRequest) {
		return false;
	}

	public abstract boolean rejectRequest();

	public Spy getSpy() {
		return spy;
	}

	public void setSpy(Spy spy) {
		this.spy = spy;
	}

	/**
	 * Cuando sale de un estado con cola de pendiente, envia los pendientes a la
	 * cola real.
	 * 
	 * @param pendingInbox
	 * @param pendingOutbox
	 */
	public void dispatchPendings(Set<Message<?>> pendingInbox,
			Set<Message<?>> pendingOutbox) {
		for (Message<?> aMessage : pendingInbox) {
			pendingInbox.remove(aMessage);
			receiveMessage(aMessage);
		}
		for (Message<?> aMessage : pendingOutbox) {
			pendingOutbox.remove(aMessage);
			sendMessage(aMessage);
		}
	}
	

}
