package ar.edu.unlp.lifia.capacitacion.domain.cryptography;

import org.jasypt.util.text.StrongTextEncryptor;

public class AdvancedEncryption extends Cryptography {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private StrongTextEncryptor textEncryptor = new StrongTextEncryptor();

	public AdvancedEncryption() {
		super();
		textEncryptor.setPassword(this.getEncryptorPassword());
	}
	
	public AdvancedEncryption(String passwd) {
		super(passwd);
		textEncryptor.setPassword(this.getEncryptorPassword());
	}
	
	public StrongTextEncryptor getTextEncryptor() {
		return textEncryptor;
	}

	public void setTextEncryptor(StrongTextEncryptor textEncryptor) {
		this.textEncryptor = textEncryptor;
	}

	
}
