package ar.edu.unlp.lifia.capacitacion.dto;

import ar.edu.unlp.lifia.capacitacion.domain.spyState.SpyState;

public class StateDto extends BaseEntityDto {

	public StateDto(SpyState state) {
		super(state.id);
		currentState = state.toString();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String currentState;

}
