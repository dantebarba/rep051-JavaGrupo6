package ar.edu.unlp.lifia.capacitacion.dao.message;

import ar.edu.unlp.lifia.capacitacion.dao.generics.GenericRepository;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;

public interface MessageDao extends GenericRepository<Message<?>> {

}
