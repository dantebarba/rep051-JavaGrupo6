package ar.edu.unlp.lifia.capacitacion.services.spy;

import java.util.List;

import ar.edu.unlp.lifia.capacitacion.dao.spy.SpyDao;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericService;

public interface SpyService extends GenericService<Spy, SpyDao> {
	Spy findByUsername(String username);

	Spy createSpy(String username, String password, Rank rank);
	
	void deleteSpy(Long spyId);
	void modifySpy(Long spyId, String username, String password,
			Rank rank, Role role);
	
	List<Message<?>> getLatestMessages(Long spyId, int count);

	/**
	 * Enviar solicitud de cono de silencio
	 * @param senderId es el usuario que inicia sesion, el que envia el request
	 * @param receptorId es el spy que recibe el request
	 * @return 
	 */
	boolean requestSilenceWith(Long senderId, Long receptorId);
	
	/**
	 * Aceptar solicitud pendiente de cono de silencio
	 * @param receptorId Es el usuario que inicio sesion supuestamente. El que acepta el request
	 * @param senderId Es el usuario que envio el request.
	 * @return 
	 */
	boolean acceptRequestWith(Long receptorId, Long senderId);
	
	/**
	 * Un espia se desconecta de un cono de silencio activo
	 * @param spyId Deberia ser el spy que està iniciado sesion y tener un cono de silencio activo
	 * @return 
	 */
	boolean disconnectSilenceRequest(Long spyId);
	
	/**
	 * Rechaza la solicitud de cono de silencio y vuelve a estado normal
	 * @param spyId deberia ser el espia que inicia sesion
	 * @return 
	 */
	boolean rejectSilenceRequest(Long spyId);

}
