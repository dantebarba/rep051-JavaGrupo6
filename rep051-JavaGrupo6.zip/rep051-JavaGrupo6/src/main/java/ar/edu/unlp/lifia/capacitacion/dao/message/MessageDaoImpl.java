package ar.edu.unlp.lifia.capacitacion.dao.message;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.GenericTypeResolver;
import org.springframework.stereotype.Repository;

import ar.edu.unlp.lifia.capacitacion.dao.generics.HibernateGenericDao;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
@Repository
public class MessageDaoImpl extends HibernateGenericDao<Message<?>> implements
		MessageDao {

	@Autowired
	public MessageDaoImpl(SessionFactory s) {
		super(s);
	}

	public Class<Message<?>> getDomainClass() {
		return (Class<Message<?>>) GenericTypeResolver.resolveTypeArgument(getClass(), HibernateGenericDao.class);
	}

}
