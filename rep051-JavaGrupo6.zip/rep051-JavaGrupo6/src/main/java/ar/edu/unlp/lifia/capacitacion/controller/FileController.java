package ar.edu.unlp.lifia.capacitacion.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.unlp.lifia.capacitacion.domain.cryptography.Cryptography;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;
import ar.edu.unlp.lifia.capacitacion.dto.CreatedTextFileDto;
import ar.edu.unlp.lifia.capacitacion.dto.SpyDto;
import ar.edu.unlp.lifia.capacitacion.services.file.FileService;

@RestController
@RequestMapping("/file")
public class FileController {
	@Autowired
	FileService fileService;

	@RequestMapping(value = "/text", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Long> createTextFile(
			@RequestParam(value = "fileName", required = true) String fileName,
			@RequestParam(value = "ownerId", required = true) Long ownerId,
			@RequestParam(value = "content", required = true) String content,
			@RequestParam(value = "description") String description,
			@RequestParam(value = "cryptoType") String cryptoType) {
		CreatedTextFileDto newFile = new CreatedTextFileDto();
		newFile.name = fileName;
		newFile.owner = new SpyDto(ownerId);
		newFile.content = content;
		newFile.id = null;
		newFile.cryptoStrategy = Cryptography.fromString(cryptoType);
		newFile.description = description;
		try {
			File<?> createdFile = fileService.createTextFile(newFile);
			return new ResponseEntity<Long>(createdFile.getId(), HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			HttpHeaders response = new HttpHeaders();
			response.add("message", e.getMessage());
			return new ResponseEntity<Long>(response, HttpStatus.BAD_REQUEST);
		}
	}

}
