package ar.edu.unlp.lifia.capacitacion.services.message;

import ar.edu.unlp.lifia.capacitacion.dao.message.MessageDao;
import ar.edu.unlp.lifia.capacitacion.domain.message.GroupMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericService;

public interface MessageService extends GenericService<Message<?>, MessageDao> {

	public IndividualMessage sendIndividualMessage(Long idSender, Long idReceiver,
			String content);

	public GroupMessage sendGroupMessage(long spySenderId, long groupId, String content);

}
