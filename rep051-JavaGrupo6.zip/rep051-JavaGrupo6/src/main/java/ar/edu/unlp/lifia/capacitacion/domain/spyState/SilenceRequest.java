package ar.edu.unlp.lifia.capacitacion.domain.spyState;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class SilenceRequest extends BaseEntity {

	private static final long serialVersionUID = 1L;
	private Spy applicant;
	private Spy requested;

	public SilenceRequest() {
		super();
	}
	
	public SilenceRequest(Spy applicant) {
		super();
		this.applicant = applicant;
	}

	public void acceptRequestWith(Spy aSpy) {
		this.requested = aSpy;

		this.requested.setState(new SilenceState(requested));
		this.applicant.setState(new SilenceState(applicant));

		this.applicant.dispatchPendings();
		this.requested.dispatchPendings();
	}

	public boolean rejectRequestWith() {
		return this.requested.rejectRequest();
	}

	public boolean isIn(Spy aSpy) {
		if (applicant == aSpy || requested == aSpy) {
			return true;
		}
		return false;
	}

	public void disconnect() {
		this.applicant.setState(new NormalState(this.applicant));
		this.requested.setState(new NormalState(this.requested));
		this.applicant.dispatchPendings();
		this.requested.dispatchPendings();
	}
}
