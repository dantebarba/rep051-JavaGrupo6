package ar.edu.unlp.lifia.capacitacion.dto;

import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class SpyDto extends BaseEntityDto {
	
	public SpyDto(Spy spy) {
		super(spy.getId());
		username = spy.getUsername();
		rank = spy.getRank().getRank();
		state = new StateDto(spy.getState());
		role = spy.getRole().getRole();
	}

	public SpyDto(Long ownerId) {
		super(ownerId);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String username;
	
	public Ranks rank;
	
	public Roles role;
	
	public StateDto state;

}
