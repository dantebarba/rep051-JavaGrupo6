package ar.edu.unlp.lifia.capacitacion.domain.accessRule;

import ar.edu.unlp.lifia.capacitacion.domain.role.Role;

public class AccessRuleRole extends AccessRule<Role> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccessRuleRole(Role role) {
		super(role);
	}

	@Override
	public AccessRuleType getTargetEntity() {
		return this.targetEntity;
	}

	@Override
	public void setTargetEntity(Role t) {
		this.targetEntity = t;
	}

}
