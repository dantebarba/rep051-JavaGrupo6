package ar.edu.unlp.lifia.capacitacion.domain.role;

import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class Boss extends Role {

	
	private static final long serialVersionUID = 1L;
	/*
	 * TODO: VER SI NECESITO EL GRUOP AQUI. QUIZAS NO LO NECESITO, PERO POR AHI
	 * SERIA EFICIENTE UNA RELACION BIDIRECCIONAL
	 * 
	 * TODO: AGREGAR COMPORTAMIENTO FALTANTE PARA JEFE
	 */
	public Boss(Spy spy) {
		super(spy, Roles.BOSS);
	}

}
