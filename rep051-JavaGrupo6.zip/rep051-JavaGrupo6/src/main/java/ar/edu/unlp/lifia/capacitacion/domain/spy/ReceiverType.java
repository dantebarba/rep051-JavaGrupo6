package ar.edu.unlp.lifia.capacitacion.domain.spy;

import ar.edu.unlp.lifia.capacitacion.domain.message.Message;

public interface ReceiverType {

	public void receiveMessage(Message<?> aMessage);

}
