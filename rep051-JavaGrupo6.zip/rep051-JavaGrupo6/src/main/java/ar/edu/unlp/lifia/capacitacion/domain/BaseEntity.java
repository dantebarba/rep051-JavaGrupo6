package ar.edu.unlp.lifia.capacitacion.domain;

import java.io.Serializable;
import java.util.Date;

import org.apache.log4j.Logger;

import ar.edu.unlp.lifia.capacitacion.aspects.LoggingAspect;

/**
 * Una entidad base que permite generalizar ciertas caracteristicas que tienen
 * todos los objetos persistibles en una base de datos.
 * 
 */
public abstract class BaseEntity implements Serializable {

	private static Logger log;
	
	private static final long serialVersionUID = 1L;
	public Long id;
	public Date createdOn;
	
	public BaseEntity() {
		createdOn = new Date();
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof BaseEntity)) {
			return false;
		}
		final BaseEntity other = (BaseEntity) obj;
		if (this.id != null && other.id != null) {
			if (this.id != other.id) {
				return false;
			} else {
				return true;
			}
		}
		return false;
	}

	protected void copy(final BaseEntity source) {
		this.id = source.id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public void setCreatedOn(Date aDate) {
		this.createdOn = aDate;
	}
	
	public Date getCreatedOn() {
		return this.createdOn;
	}

	public static Logger log(Class<?> clazz) {
		if (log == null) {
			log = Logger.getLogger(clazz.getName());
			log.info("SETEA DOMINIO LOGGER");
		} 
		
		return log;
	}

	public static void setLog(Logger log) {
		BaseEntity.log = log;
	}

}
