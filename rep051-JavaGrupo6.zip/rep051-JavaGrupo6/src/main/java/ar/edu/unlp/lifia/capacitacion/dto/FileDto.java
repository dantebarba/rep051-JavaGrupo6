package ar.edu.unlp.lifia.capacitacion.dto;

import ar.edu.unlp.lifia.capacitacion.domain.cryptography.Cryptography;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;

public class FileDto extends BaseEntityDto {

	public FileDto() {
		
	}
	
	public FileDto(File<?> aFile) {
		super(aFile.getId());
		this.name = aFile.getFileName();
		this.description = aFile.getDescription();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String content;
	
	public String name;
	
	public SpyDto owner;
	
	public String description;
	
	public Cryptography cryptoStrategy;
	
}
