package ar.edu.unlp.lifia.capacitacion.dto;

import ar.edu.unlp.lifia.capacitacion.domain.message.GroupMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.ReceiverType;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class GroupMessageDto extends BaseEntityDto {
	
	public GroupMessageDto(GroupMessage message) {
		super(message.getId());
		sender = new SpyDto(message.getSender());
		receiver = new GroupDto(message.getReceiver());
		content = message.getContent();
	}

	public GroupMessageDto(Long ownerId) {
		super(ownerId);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SpyDto sender;

	public GroupDto receiver;
	
	public String content;
	

}
