package ar.edu.unlp.lifia.capacitacion.dao.accessRule;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ar.edu.unlp.lifia.capacitacion.dao.generics.HibernateGenericDao;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;

@Repository
public class AccessRuleDaoImpl extends HibernateGenericDao<AccessRule> implements AccessRuleDao {
	@Autowired
	protected AccessRuleDaoImpl(SessionFactory s) {
		super(s);
	}

	@Override
	public Class<AccessRule> getDomainClass() {
		return AccessRule.class;
	}

}
