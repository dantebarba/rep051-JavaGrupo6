package ar.edu.unlp.lifia.capacitacion.dao.file;

import java.util.List;

import ar.edu.unlp.lifia.capacitacion.dao.generics.GenericRepository;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;

public interface FileDao extends GenericRepository<File<?>> {
	/**
	 * 
	 * @param username
	 * @return A list of all files owned by aSpy
	 */
	List<File<?>> findFileByOwner(Long spyId);
}
