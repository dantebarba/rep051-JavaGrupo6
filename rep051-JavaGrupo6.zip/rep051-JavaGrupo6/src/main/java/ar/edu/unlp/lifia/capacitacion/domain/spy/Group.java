package ar.edu.unlp.lifia.capacitacion.domain.spy;

import java.util.HashSet;
import java.util.Set;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleGroup;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleType;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Boss;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;

public class Group extends BaseEntity implements AccessRuleType, ReceiverType {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	
	private Set<Role> spies;
	private String name;
	private String description;

	/**
	 * @param boss
	 * @param name
	 * @param description
	 * @throws Exception
	 */
	public Group(Spy boss, String name, String description) {
		super();
		super.log(Group.class).info("se crea clase: " + Group.class.getName());
		this.spies = new HashSet<Role>();
		// Este espia deberia ser veterano. No es problema del dominio.
		
		boss.setRole(new Boss(boss));
		this.spies.add(boss.getRole());
		setName(name);
		setDescription(description);
	}

	/**
	 * Envia un mensaje a cada integrante del grupo (incluido el jefe)
	 * 
	 * @param aMessage
	 * @return void
	 */
	public void receiveMessage(Message<?> aMessage) {
		for (Role r : this.spies) {
			r.getSpy().receiveMessage(aMessage);
		}
	}

	public AccessRuleGroup getAccessRule() {
		return new AccessRuleGroup(this);
	}

	public boolean validateAgainst(Spy aSpy) {
		return this.containsSpy(aSpy);
	}

	/**
	 * Eliminar un spy del Group. { solo veterano ( o jefe? ) puede hacerlo }
	 * 
	 * @param spy
	 * @return true si pudo, false si no existe
	 */
	public boolean deleteSpy(Spy spy) {
		// buscar el espia con cualquier rol y eliminarlo
		for (Role r : this.spies) {
			if (r.getSpy() == spy) {
				this.spies.remove(r);
				return true;
			}
		}
		return false;
		
	}

	/**
	 * Agregar Spy { solo veterano ( o jefe? ) puede hacerlo }
	 * 
	 * @param spy
	 * @return si el espía pudo ser agregado. (no se deberian permitir
	 *         repetidos)
	 */
	public boolean addSpy(Spy spy, Roles role) {
		if (!this.containsSpy(spy)){
			return this.spies.add(new Role(spy, role));
		}
		return false;
	}

	/**
	 * 
	 * @param spy
	 * @return true si encuentra al espia dentro del grupo. Al crear un Role, lo
	 *         unico que se fija es si el espia se encuentra dentro del role
	 */
	public boolean containsSpy(Spy spy) {
		for (Role r : this.spies) {
			if (r.getSpy().equals(spy)) {
				return true;
			}
		}
		return false;

		// return this.spies.contains(new Role(spy, Roles.UNDEFINED));
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public Set<Role> getSpies() {
		return spies;
	}

	public void setSpies(Set<Role> spies) {
		this.spies = spies;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * 
	 * @return Role, un espia del grupo que es jefe ( en este caso es unico )
	 */
	public Role getBoss() {
		for (Role r : this.spies) {
			if (r.getRole().name() == Roles.BOSS.name()) {
				return r;
			}
		}
		return null;
	}
}
