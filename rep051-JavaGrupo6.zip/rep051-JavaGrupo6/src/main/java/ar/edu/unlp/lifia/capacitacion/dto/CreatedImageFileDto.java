package ar.edu.unlp.lifia.capacitacion.dto;


public class CreatedImageFileDto extends FileDto {


	private static final long serialVersionUID = 1L;

}
