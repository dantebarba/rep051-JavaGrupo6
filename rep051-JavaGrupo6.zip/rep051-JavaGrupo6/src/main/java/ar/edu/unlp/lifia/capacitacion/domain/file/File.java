package ar.edu.unlp.lifia.capacitacion.domain.file;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.domain.cryptography.Cryptography;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

/**
 * 
 * @throws SecurityException
 * 
 * 
 */

public abstract class File<T> extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long size;

	private String fileName;

	private Date dateOfCreation;

	private String description;

	private Spy owner;

	private List<AccessRule<?>> accessRulesForFile = new ArrayList<AccessRule<?>>();

	protected T content;

	private Set<String> allowedIpAddresses = new HashSet<String>();

	private Cryptography encryptionStrategy;
	
	public File(T content, Cryptography encryptionStrategy) {
		this.setEncryptionStrategy(encryptionStrategy);
		this.setContent(content);
	}
	
	public File(T content,  Cryptography encryptionStrategy, Spy anOwner) {
		this(content, encryptionStrategy);
		this.setOwner(anOwner);
	}

	public File() {
	}


	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Date getDateOfCreation() {
		return dateOfCreation;
	}

	public void setDateOfCreation(Date dateOfCreation) {
		this.dateOfCreation = dateOfCreation;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Spy getOwner() {
		return owner;
	}

	public void setOwner(Spy owner) {
		this.owner = owner;
	}

	/**
	 * 
	 * @param aSpy
	 * @return Access Rule List
	 */
	public List<AccessRule<?>> getAccessRulesForFile(Spy aSpy) {
		// FIXME: return a cloned list.
		if (this.isOwner(aSpy)) {
			return this.accessRulesForFile;
		} else {
			throw new SecurityException("Solo el dueño puede editar las reglas de acceso");
		}
	}

	/**
	 * Metodo privado para restringir el acceso a la instancia de permisos.
	 * Evitamos efectos colaterales.
	 * 
	 * @return
	 */
	private List<AccessRule<?>> getAccessRulesForFileProtected() {
		return this.accessRulesForFile;
	}

	public void addAccessRule(AccessRule<?> rule, Spy anOwner) {
		this.getAccessRulesForFile(anOwner).add(rule);
	}

	public boolean autenticateWith(Spy aSpy) {
		// FIXME mocked. No conocemos la implementacion
		// al momento
		return true;
	}

	/**
	 * 
	 * @param aSpy
	 * @throws SecurityException
	 *             Validamos el acceso al archivo contra sus permisos. En caso
	 *             de fallo se eleva una excepción.
	 * 
	 */

	public boolean validateAgainst(Spy aSpy) {
		return (validateIpAddress(aSpy.getIpAddress()) && validateAccessRules(aSpy));
	}

	public boolean validateAccessRules(Spy aSpy) {
		for (AccessRule<?> eachAccessRule : this.getAccessRulesForFileProtected()) {
			if (!eachAccessRule.validateAgainst(aSpy)) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Valida si dentro de la lista de Ips aceptadas existe una IP que 
	 * coincida con la del usuario
	 * @param ipAddress
	 * @return true si coincide la IP o la validacion esta desactivada. 
	 * False si no valida correctamente.
	 */
	public boolean validateIpAddress(String ipAddress) {
		if (allowedIpAddresses.isEmpty()) {
			return true;
		}
		else {
			for (String eachIp : allowedIpAddresses) {
				if (eachIp.equals(ipAddress)) {
					return true;
				}
			}
			return false;
		}
	}

	public T getContent(Spy aSpy) {
		if (this.isOwner(aSpy) || this.validateAgainst(aSpy)) {
			return this.getContent();
		} else {
			throw new SecurityException();
		}
	}

	private T getContent() {
		return (this.hasContent() ? this.decrypt(this.content) : null);
	}

	public void setContent(T content, Spy aSpy) {
		if (this.isOwner(aSpy) || this.validateAgainst(aSpy)) {
			this.setContent(content);
		} else {
			throw new SecurityException();
		}
	}

	private void setContent(T content) {
		if (content != null) {
			if (this.hasEncryptionEnabled()) {
				this.content = this.encrypt(content);
			} else {
				throw new IllegalStateException(
						"No se ha definido una estrategia de encriptacion para este archivo");
			}
		}
	}
	
	private boolean hasContent() {
		return (this.content != null);
	}

	public boolean hasEncryptionEnabled() {
		return (this.getEncryptionStrategy() != null);
	}

	protected Cryptography getEncryptionStrategy() {
		return this.encryptionStrategy;
	}

	public List<AccessRule<?>> getAccessRulesForFile() {
		return accessRulesForFile;
	}

	public void setAccessRulesForFile(List<AccessRule<?>> accessRulesForFile) {
		this.accessRulesForFile = accessRulesForFile;
	}

	public Set<String> getAllowedIpAddresses() {
		return allowedIpAddresses;
	}

	public void setAllowedIpAddresses(Set<String> allowedIpAddresses) {
		this.allowedIpAddresses = allowedIpAddresses;
	}
	
	/*
	 * Actualiza la metodologia de encriptacion y recodifica el contenido
	 * segun la nueva metodologia.
	 */
	public void setEncryptionStrategy(Cryptography cryptoStrategy) {
		T decryptedContent = this.getContent();
		this.encryptionStrategy = cryptoStrategy;
		this.setContent(decryptedContent);
	}
	
	protected abstract T encrypt(T content);
	
	protected abstract T decrypt(T content);

	public boolean isOwner(Spy anOwner) {
		return anOwner.equals(this.getOwner());
	}

	public boolean deleteAccessRule(AccessRule<?> anAccessRule, Spy anOwner) {
		return this.getAccessRulesForFile(anOwner).remove(anAccessRule);
	}
	

	public void removeAllIps() {
		this.getAllowedIpAddresses().clear();
	}
	
	public void removeIp(String ipAddr) {
		this.getAllowedIpAddresses().remove(ipAddr);
	}
	
	public void addIp(String ipAddr) {
		this.getAllowedIpAddresses().add(ipAddr);
	}

}
