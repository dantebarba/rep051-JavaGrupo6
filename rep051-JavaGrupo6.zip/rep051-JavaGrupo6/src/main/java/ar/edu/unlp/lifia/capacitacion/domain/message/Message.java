package ar.edu.unlp.lifia.capacitacion.domain.message;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.spy.ReceiverType;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public abstract class Message<T extends ReceiverType> extends BaseEntity {

	private static final long serialVersionUID = 1L;
	@JsonManagedReference
	private Spy sender;
	@JsonManagedReference
	private T receiver;
	private String content;
	private Date date;

	public Message(Spy sender, T receiver, String content) {
		super();
		super.log(Message.class).info("se crea clase: " + Message.class.getName());
		this.sender = sender;
		this.receiver = receiver;
		this.content = content;
		this.setDate(new Date());
	}

	public Message() {

	}

	public Spy getSender() {
		return sender;
	}

	public void setSender(Spy sender) {
		this.sender = sender;
	}

	public T getReceiver() {
		return receiver;
	}

	public void setReceiver(T receiver) {
		this.receiver = receiver;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
