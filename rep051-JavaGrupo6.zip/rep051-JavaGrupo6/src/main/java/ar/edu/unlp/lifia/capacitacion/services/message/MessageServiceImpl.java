package ar.edu.unlp.lifia.capacitacion.services.message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import ar.edu.unlp.lifia.capacitacion.dao.message.MessageDao;
import ar.edu.unlp.lifia.capacitacion.domain.message.GroupMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericServiceImpl;
import ar.edu.unlp.lifia.capacitacion.services.group.GroupService;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

@Service
@Transactional
public class MessageServiceImpl extends
		GenericServiceImpl<Message<?>, MessageDao> implements MessageService {

	@Autowired
	SpyService spyService;

	@Autowired
	GroupService groupService;

	/**
	 * 
	 * @param spySenderId
	 *            spy loggeado que quiere enviar el mensaje
	 * @param idReceiver
	 *            spy al que desea enviar el mensaje
	 * @param content
	 *            contenido del mensaje
	 * @return
	 */
	public IndividualMessage sendIndividualMessage(Long idSender,
			Long idReceiver, String content) {
		Assert.notNull(idSender, "El id del usuario emisor no puede ser null");
		Assert.notNull(idReceiver,
				"El id del usuario receptor no puede ser null");
		Assert.notNull(content, "El contenido del mensaje no puede ser null");
		Spy sender = spyService.findById(idSender);
		Spy receiver = spyService.findById(idReceiver);
		IndividualMessage message = new IndividualMessage(sender, receiver,
				content);
		sender.sendMessage(message);
		this.save(message);
		spyService.update(sender);
		spyService.update(receiver);
		return message;

	}

	public void sendGroupMessage() {

	}

	@Override
	/**
	 * @param spySenderId spy loggeado que quiere enviar el mensaje
	 * @param groupId grupo al que desea enviar el mensaje, debe pertenecer a ese grupo
	 * @param content contenido del mensaje
	 */
	public GroupMessage sendGroupMessage(long spySenderId, long groupId,
			String content) {
		Assert.notNull(spySenderId);
		Assert.notNull(groupId);
		Assert.notNull(content);

		Spy sender = spyService.findById(spySenderId);
		Assert.notNull(sender);

		Group group = groupService.findById(groupId);
		Assert.notNull(group);
		Assert.isTrue(group.containsSpy(sender),
				"Para enviar un mensaje grupal, debe pertenecer al grupo");

		GroupMessage message = new GroupMessage(sender, group, content);

		sender.sendMessage(message);

		dao.save(message);
		spyService.update(sender);
		groupService.update(group);
		return message;
	}

}
