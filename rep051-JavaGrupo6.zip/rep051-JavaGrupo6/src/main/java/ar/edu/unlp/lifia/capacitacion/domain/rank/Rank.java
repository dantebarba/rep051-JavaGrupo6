package ar.edu.unlp.lifia.capacitacion.domain.rank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleRank;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleType;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class Rank extends BaseEntity implements AccessRuleType{


	private static final long serialVersionUID = 1L;

	@JsonIgnore
	public AccessRuleRank getAccessRule() {
		return new AccessRuleRank(this);	
	}
	private Ranks rank; 
	
	public Rank() {
		
	}
	
	public Rank(Ranks rank){
		super();//va esto?
		this.setRank(rank);
	}

	public boolean validateAgainst(Spy aSpy) {
		return aSpy.getRank().equals(this.getRank());
	}

	public Ranks getRank() {
		return rank;
	}

	public void setRank(Ranks rank) {
		this.rank = rank;
	}

	public boolean equals(Ranks rank) {
		return this.rank.name().equals(rank.name());
	}
	
	//factorias
	
	public static Rank getVeteran() {
		return new Rank(Ranks.VETERAN);
	}
	
	public static Rank getNovice() {
		return new Rank(Ranks.NOVICE);
	}
	
	public static Rank getCounterintelligence() {
		return new Rank(Ranks.COUNTERINTELLIGENCE);
	}
}
