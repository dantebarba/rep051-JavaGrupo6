package ar.edu.unlp.lifia.capacitacion.domain.file;

import ar.edu.unlp.lifia.capacitacion.domain.cryptography.Cryptography;



public class Text extends File<String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public Text(String content, Cryptography anEncryptionStrategy) {
		super(content, anEncryptionStrategy);
	}

	public Text() {
		super();
	}

	@Override
	protected String encrypt(String content) {
		return this.getEncryptionStrategy().encrypt(content);
	}
	
	@Override
	protected String decrypt(String content) {
		return this.getEncryptionStrategy().decrypt(content);
	}


}
