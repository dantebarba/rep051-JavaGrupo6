package ar.edu.unlp.lifia.capacitacion.services.generics;

import java.io.Serializable;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import ar.edu.unlp.lifia.capacitacion.dao.generics.GenericRepository;

public abstract class GenericServiceImpl<T, D extends GenericRepository<T>>
		implements GenericService<T, D> {

	static Logger log = Logger.getLogger(GenericServiceImpl.class.getName());
	
	@Autowired
	public D dao;

	public T findById(final Serializable id) {
		log.debug("Ejecuto un findById");
		Assert.notNull(id, "El numero de id ingresado no es valido");
		return dao.findById(id);
	}

	public List<T> findAll() {
		log.debug("Ejecuto un FindAll");
		return dao.findAll();
	}

	public void save(final T entity) {
		log.debug("Ejecuto un saveOrUpdate");
		dao.saveOrUpdate(entity);
	}

	public void update(final T entity) {
		log.debug("Ejecuto un update");
		dao.update(entity);
	}
}
