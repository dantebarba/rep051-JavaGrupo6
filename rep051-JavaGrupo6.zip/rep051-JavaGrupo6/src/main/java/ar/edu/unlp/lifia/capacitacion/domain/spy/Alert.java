package ar.edu.unlp.lifia.capacitacion.domain.spy;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;

public class Alert extends BaseEntity {

}
