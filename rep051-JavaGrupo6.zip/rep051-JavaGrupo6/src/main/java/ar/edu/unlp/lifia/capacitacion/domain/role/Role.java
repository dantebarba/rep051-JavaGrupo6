package ar.edu.unlp.lifia.capacitacion.domain.role;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleRole;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleType;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class Role extends BaseEntity implements AccessRuleType {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonBackReference
	private Spy spy;
	protected Roles role;

	public Role(Spy spy, Roles role) {
		this.setSpy(spy);
		this.role = role;
	}

	public Role() {
	}

	public void getCoding() {
		// TODO: Falta
		// asumo delegar al espia y paso el rol?
	}

	public void getCryptography() {
		// TODO: falta
		// asumo delegar al espia y paso el rol?
	}
	@JsonIgnore
	public AccessRuleRole getAccessRule() {
		return new AccessRuleRole(this);
	}

	public boolean validateAgainst(Spy aSpy) {
		return this.getRole().equals(aSpy.getRole().getRole());
	}
	
	public Spy getSpy() {
		return spy;
	}
	
	public void setSpy(Spy spy) {
		this.spy = spy;
	}

	public Roles getRole() {
		return role;
	}

	public void setRole(Roles role) {
		this.role = role;
	}

	/**
	 * Dos roles son iguales, si los espias que contienen son iguales De esta
	 * manera evitamos agregar dos veces el mismo espia con distinto Role
	 * 
	 * @param role
	 * @return
	 */
	public boolean equals(Role role) {
		// TODO: Ver porque no anda el equals de Spy
		return this.spy.getId().equals(role.spy.getId());
	}

	/* Factorias */
	public Role getBOSS(Spy spy) {
		return new Role(spy, Roles.BOSS);
	}

	public Role getPRIVATE(Spy spy) {
		return new Role(spy, Roles.PRIVATE);
	}

	public Role getMOLE(Spy spy) {
		return new Role(spy, Roles.MOLE);
	}

	public Role getUNDEFINED(Spy spy) {
		return new Role(spy, Roles.UNDEFINED);
	}

}
