package ar.edu.unlp.lifia.capacitacion.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.dto.SpyDto;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

@RestController
@RequestMapping("/spy")
public class SpyController {
	@Autowired
	private SpyService spyService;

	@RequestMapping(method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Long> createSpy(
			@RequestParam(value = "username", required = true) String username,
			@RequestParam(value = "password", required = true) String password,
			@RequestParam(value = "rank", required = true) String rank) {

		Spy aSpy = spyService.createSpy(username, password,
				new Rank(Ranks.valueOf(rank)));
		return new ResponseEntity<Long>(aSpy.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.GET)
	public @ResponseBody
	ResponseEntity<SpyDto> findSpy(
			@RequestParam(value = "id", required = true) Long id) {
		Spy result = spyService.findById(id);
		if (result == null) {
			return new ResponseEntity<SpyDto>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<SpyDto>(new SpyDto(result), HttpStatus.OK);
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<List<SpyDto>> findAll() {
		List<Spy> result = spyService.findAll();
		List<SpyDto> resultAsDto = this.listToDto(result);
		if (result == null) {
			return new ResponseEntity<List<SpyDto>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<SpyDto>>(resultAsDto, HttpStatus.OK);
	}

	private List<SpyDto> listToDto(List<Spy> aList) {
		List<SpyDto> aResult = new ArrayList<SpyDto>();
		for (Spy each : aList) {
			aResult.add(new SpyDto(each));
		}
		return aResult;
	}

	@RequestMapping(method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Boolean> deleteSpy(
			@RequestParam(value = "id", required = true) Long id) {
		try {
			spyService.deleteSpy(id);
			return new ResponseEntity<Boolean>(true, HttpStatus.GONE);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(HttpStatus.NOT_FOUND);
		}
	}

	// TODO: deberia ser con la sesion esto.
	@RequestMapping(value = "/requestSilenceWith", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Boolean> requestSilenceWith(
			@RequestParam(value = "senderId", required = true) Long senderId,
			@RequestParam(value = "receiverId", required = true) Long receiverId) {
		try {
			return new ResponseEntity<Boolean>(spyService.requestSilenceWith(
					senderId, receiverId), HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.add("message", e.getMessage());
			return new ResponseEntity<Boolean>(responseHeaders,
					HttpStatus.BAD_REQUEST);
		}
	}
}