/**
 * 
 */
package ar.edu.unlp.lifia.capacitacion.domain.role;

/**
 * Enumerativo utilizado para el tipo de rol ( se podría usar par a
 *
 */
public enum Roles {
	BOSS, PRIVATE, MOLE, UNDEFINED;// JEFE, SOLDADORASO, TOPO
}
