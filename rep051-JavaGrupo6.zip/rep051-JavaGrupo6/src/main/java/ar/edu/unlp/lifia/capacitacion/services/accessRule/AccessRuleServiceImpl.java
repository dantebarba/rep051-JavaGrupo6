package ar.edu.unlp.lifia.capacitacion.services.accessRule;

import org.springframework.stereotype.Service;

import ar.edu.unlp.lifia.capacitacion.dao.accessRule.AccessRuleDao;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.services.generics.GenericServiceImpl;

@Service
public class AccessRuleServiceImpl extends GenericServiceImpl<AccessRule, AccessRuleDao> implements AccessRuleService {
	
}
