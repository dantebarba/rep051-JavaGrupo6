package ar.edu.unlp.lifia.capacitacion.domain.coding;

import ar.edu.unlp.lifia.capacitacion.domain.BaseEntity;

public class Coding extends BaseEntity {
	
}
