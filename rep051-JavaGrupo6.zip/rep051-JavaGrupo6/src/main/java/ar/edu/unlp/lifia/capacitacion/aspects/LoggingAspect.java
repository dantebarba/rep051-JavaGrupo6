package ar.edu.unlp.lifia.capacitacion.aspects;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.AfterThrowing;
/**
 * 
 * LoggingServices.
 * Tuve qeu agregar el bean a mano, no andan sino los aspectos. 
 * Loggea todas las clases dentro del paquete Services. 
 * loggea : 
 * 1- cuando entra al servicio
 * 2.cuando sale del servicio
 * 3.en el caso de que ocurra una excepci�n en el servicio
 *
 */
@Aspect
public class LoggingAspect {

	static Logger log = Logger.getLogger(LoggingAspect.class.getName());

	@Pointcut("within(ar.edu.unlp.lifia.capacitacion.services..*)")
	private void allServicesMethods() {
	}
	
	@Pointcut("within(ar.edu.unlp.lifia.capacitacion.dao..*)")
	private void allDaoMethods(){}
	
	@Pointcut("within(ar.edu.unlp.lifia.capacitacion.domain..*)")
	private void allDomainMethods(){}
	
	@Before("allServicesMethods()")
	public void beforeAdvice(JoinPoint joinpoint) {
		log.info("_________________LOG BEFORE__________________");
		log.info("SERVICE => RUNNING: " + joinpoint.getSignature().getName());
		log.info("________________________________");
	}


	@AfterReturning(pointcut = "allServicesMethods()", returning = "result")
	public void afterAdvice(JoinPoint joinpoint, Object result) {
		log.info("_________________LOG AfterReturning__________________");
		log.info("SERVICE  => RUNNING: " + joinpoint.getSignature().getName() + " RESULT: "
				+ result);
		log.info("________________________________");
	}


	@AfterThrowing(pointcut = "allServicesMethods()", throwing = "ex")
	public void AfterThrowingAdvice(JoinPoint joinpoint,
			IllegalArgumentException ex) {
		log.error("_________________LOG AfterTHROWING__________________");
		log.error("SERVICE => RUNNING: " + joinpoint.getSignature().getName()
				+ " EXCEPCION: " + ex);
		log.error("________________________________");
	}

}
