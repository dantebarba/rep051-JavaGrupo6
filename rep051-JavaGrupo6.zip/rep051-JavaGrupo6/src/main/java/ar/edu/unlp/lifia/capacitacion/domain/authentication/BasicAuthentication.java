package ar.edu.unlp.lifia.capacitacion.domain.authentication;

public class BasicAuthentication {
	private Long idBasicAuthentication;

}
