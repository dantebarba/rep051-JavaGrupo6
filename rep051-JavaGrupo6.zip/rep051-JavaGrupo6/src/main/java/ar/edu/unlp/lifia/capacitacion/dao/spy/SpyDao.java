package ar.edu.unlp.lifia.capacitacion.dao.spy;

import ar.edu.unlp.lifia.capacitacion.dao.generics.GenericRepository;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public interface SpyDao extends GenericRepository<Spy> {

	Spy findByUsername(String username);
}
