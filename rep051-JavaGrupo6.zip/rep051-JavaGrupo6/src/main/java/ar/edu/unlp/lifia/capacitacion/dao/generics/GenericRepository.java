package ar.edu.unlp.lifia.capacitacion.dao.generics;

import java.io.Serializable;
import java.util.List;

public interface GenericRepository<T> {

	public Class<T> getDomainClass();

	public Serializable save(final T entity);

	public void delete(final T entity);

	public void deleteById(final Long id);

	public void deleteById(final Serializable id);

	public void update(final T entity);

	public void saveOrUpdate(final T entity);

	public T findById(final Serializable id);

	public List<T> findAll();

	public int countAll();

	public List<T> findByExample(final T exampleObject);
	
	public void flush();

}
