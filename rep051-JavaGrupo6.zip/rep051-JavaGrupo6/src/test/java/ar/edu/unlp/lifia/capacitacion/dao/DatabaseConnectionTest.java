package ar.edu.unlp.lifia.capacitacion.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.ClassPathResource;

import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class DatabaseConnectionTest {
	private Session session = null;
	private Spy spy = null;
	private SessionFactory sessionFactory;

	@Before
	public void setUp() {
		GenericApplicationContext ctx = new GenericApplicationContext();
		XmlBeanDefinitionReader xmlReader = new XmlBeanDefinitionReader(ctx);
		xmlReader.loadBeanDefinitions(new ClassPathResource(
				"application-context-test.xml"));
		// PropertiesBeanDefinitionReader propReader = new
		// PropertiesBeanDefinitionReader(ctx);
		// propReader.loadBeanDefinitions(new
		// ClassPathResource("otherBeans.properties"));
		ctx.refresh();
		this.sessionFactory = (SessionFactory) ctx.getBean("sessionFactory");
		session = sessionFactory.openSession();
		this.spy = new Spy("Carlos", "123456", new Rank(Ranks.NOVICE));
	}

	@Test
	public void testPersistance() {
		Assert.assertEquals(spy, spy);
		Spy otherSpy = new Spy();
		otherSpy.setId((Long) session.save(spy));
		
		session.flush();
		session.clear();
		session.close();
		
		session = sessionFactory.openSession();
		otherSpy = (Spy) session.get(Spy.class, otherSpy.getId());
		
		Assert.assertEquals(spy, otherSpy);
	}

	@After
	public void tearDown() {
		session.close();
		sessionFactory.close();
	}
}
