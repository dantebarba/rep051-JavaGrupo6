package ar.edu.unlp.lifia.capacitacion.dao.message;

import static org.junit.Assert.assertEquals;

import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.lifia.capacitacion.dao.generic.AbstractDaoTest;
import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class MessageDaoTest extends AbstractDaoTest<Message<?>, MessageDao> {

	private Spy spy1;
	private Spy spy2;
	private Message<Spy> message1;

	@Before
	public void setUp() {
		// message2 = new GroupMessage(spy1, spy2, "Mensaje 2");
		spy1 = new Spy("User1", "1234", new Rank(Ranks.NOVICE));
		spy2 = new Spy("User2", "1234", new Rank(Ranks.NOVICE));
		new Spy("User3", "user3", new Rank(Ranks.NOVICE));

		message1 = new IndividualMessage(spy1, spy2, "bla bla bla");
	}

	@Test
	@Transactional
	public void testSendMessageNormalStateToNormalState() {

		Long id = (Long) dao.save(message1);

		assertEquals(dao.findById(id), message1);
	}

	@Override
	public void tearDown() throws Exception {
		dao.delete(message1);
	}
}
