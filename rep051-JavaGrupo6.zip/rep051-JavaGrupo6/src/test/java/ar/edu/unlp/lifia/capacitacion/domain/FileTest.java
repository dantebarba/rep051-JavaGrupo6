package ar.edu.unlp.lifia.capacitacion.domain;

import java.util.HashSet;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleIndividual;
import ar.edu.unlp.lifia.capacitacion.domain.cryptography.AdvancedEncryption;
import ar.edu.unlp.lifia.capacitacion.domain.cryptography.BasicEncryption;
import ar.edu.unlp.lifia.capacitacion.domain.file.Text;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class FileTest {

	private Text file;
	private String content;
	private Spy userAllowed;
	private Spy userDisallowed;
	private String ipAddress;
	private String incorrectIpAddress;

	@Before
	public void setUp() {
		CryptographyTest.enableJCE();
		this.content = "This is the file content";
		this.file = new Text(content, new BasicEncryption());

		userAllowed = new Spy("Carlitos", "1234", new Rank(Ranks.NOVICE));
		this.file.setOwner(userAllowed);
		
		userDisallowed = new Spy("Pablito", "1234", new Rank(Ranks.NOVICE));

		AccessRule<Spy> accessRule = new AccessRuleIndividual(userAllowed);
		this.file.addAccessRule(accessRule, userAllowed);
		
		ipAddress = "10.0.0.1";
		incorrectIpAddress = "5.1.1.1";
		
		this.file.getAllowedIpAddresses().add(ipAddress);

	}

	@Test
	public void testValidateAgainst() {
		Assert.assertEquals("user" + this.userAllowed.getUsername()
				+ " no pudo acceder al archivo",
				this.file.validateAccessRules(this.userAllowed), true);

	}

	@Test
	public void testValidateAgainstNotAllowed() {
		Assert.assertEquals("user" + this.userDisallowed.getUsername()
				+ " no pudo acceder al archivo",
				this.file.validateAccessRules(this.userDisallowed), false);
	}
	
	@Test
	public void testValidateIpAddress() {
		Assert.assertEquals(true, file.validateIpAddress(ipAddress));
	}
	
	@Test
	public void testIncorrectIpAddress() {
		Assert.assertEquals(false, file.validateIpAddress(incorrectIpAddress));
	}
	
	@Test
	public void testFileEncryption() {
		this.file.removeAllIps();
		this.file.setEncryptionStrategy(new AdvancedEncryption());
		Assert.assertEquals(this.content, file.getContent(userAllowed));
		// cryptography switch
		this.file.setEncryptionStrategy(new BasicEncryption());
		Assert.assertEquals(this.content, file.getContent(userAllowed));
		
	}

}
