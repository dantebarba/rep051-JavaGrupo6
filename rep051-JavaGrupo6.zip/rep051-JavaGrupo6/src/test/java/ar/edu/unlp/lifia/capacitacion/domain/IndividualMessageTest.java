package ar.edu.unlp.lifia.capacitacion.domain;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class IndividualMessageTest {
	private Spy spy1;
	private Spy spy2;
	private Spy spy3;
	private Message<Spy> message1;
	private Message<Spy> message2;
	private Message<Spy> message3;
	private Message<Spy> message4;
	private Message<Spy> message5;
	private Message<Spy> message6;
	private Message<Spy> message7;
	private Message<Spy> message8;

	@Before
	public void setUp() {
		spy1 = new Spy("User1", "1234", new Rank(Ranks.NOVICE));
		spy2 = new Spy("User2", "1234", new Rank(Ranks.NOVICE));
		spy3 = new Spy("User3", "user3", new Rank(Ranks.NOVICE));
		message1 = new IndividualMessage(spy1, spy2, "bla bla bla");
		message2 = new IndividualMessage(spy1, spy2, "Mensaje 2");
		message3 = new IndividualMessage(spy3, spy1, "Mensaje 3");
		message4 = new IndividualMessage(spy2, spy3, "Mensaje 4");
		message5 = new IndividualMessage(spy2, spy1, "Mensaje 5 silencioso");
		message6 = new IndividualMessage(spy1, spy2, "Mensaje 6");
		message7 = new IndividualMessage(spy1, spy2, "Mensaje 7");
		message8 = new IndividualMessage(spy1, spy2, "Mensaje 8");

	}


	@Test
	public void testGetLatestMessages() {
		// spy1 envia mensaje a spy2. Ambos en estado normal
		spy1.sendMessage(message1);
		spy1.sendMessage(message2);
		spy1.sendMessage(message6);
		spy1.sendMessage(message7);
		spy1.sendMessage(message8);

		Assert.assertEquals(message8, spy2.getLatestInbox(1).get(0)); // trae el ultimo mensaje recibido. message8
		Assert.assertEquals(message2, spy2.getLatestInbox(4).get(0)); // trae los dos ultimos mensajes y comparo por el anteultimo
		Assert.assertEquals(message8, spy1.getLatestOutbox(1).get(0)); // trae el ultimo mensaje enviado. message8
		Assert.assertEquals(message2, spy1.getLatestOutbox(4).get(0)); // trae los dos ultimos mensajes enviados y comparo por el anteultimo
		
	}

	@Test
	public void testSendMessageNormalStateToNormalState() {
		// spy1 envia mensaje a spy2. Ambos en estado normal
		spy1.sendMessage(message1);
		spy1.sendMessage(message1); // no se deberia recibir duplicados
		Assert.assertEquals(1, spy1.getOutboxSize()); // outbox spy1 contiene mensaje enviado a spy2
		Assert.assertEquals(0, spy1.getInboxSize());
		Assert.assertEquals(1, spy2.getInboxSize()); // inbox spy2 contiene mensaje enviado por spy1
		Assert.assertEquals(0, spy2.getOutboxSize());
		
	}
	
	@Test
	public void testSendMessageNormalStateToPendingState() {
		// spy1 envia solicitud de silencio a spy2. spy3 envia mensaje a spy2,
		// que esta como pendiente

		spy1.requestSilenceWith(spy2);

		spy1.sendMessage(message2); // message2 deberia encolarse en pendingOutbox de spy1
		Assert.assertEquals(0, spy1.getOutboxSize());
		Assert.assertEquals(1, spy1.getPendingOutboxSize());
		Assert.assertEquals(0, spy1.getPendingInboxSize());

		Assert.assertEquals(spy2.getOutboxSize(), 0);
		Assert.assertEquals(spy2.getPendingOutboxSize(), 0);
		Assert.assertEquals(spy2.getPendingInboxSize(), 0);
		Assert.assertEquals(spy2.getInboxSize(), 0);

		
		spy3.sendMessage(message3); // este mensaje deberia encolarse en
									// pendinginbox de spy1 hasta que vuelva al
									// estado normal

		Assert.assertEquals(spy1.getPendingInboxSize(), 1);
		Assert.assertEquals(spy3.getOutboxSize(), 1);

	}

	@Test
	public void testSendMessageNormalStateToSilenceState() {
		spy1.sendMessage(message1);
		spy1.requestSilenceWith(spy2);
		spy1.sendMessage(message2); // message2 deberia encolarse en
									// pendingOutbox de spy1


		spy3.sendMessage(message3); // este mensaje deberia encolarse en
		// pendinginbox de spy1 hasta que vuelva al
		// estado normal

		// spy2 acepta solicitud de silencio de spy1.

		spy2.acceptSilenceRequest(spy2.getSilenceRequest()); // cuando spy2 se
																// silencia con
																// spy1, spy2
																// recibe el
																// mensaje de
																// spy1 que este
																// tenia
																// encolado

		Assert.assertEquals(spy1.getPendingOutboxSize(), 0); // cola vacia.
																// Mensaje
																// enviado a
																// spy2
		Assert.assertEquals(spy1.getPendingInboxSize(), 1); // mensaje pendiente
															// enviado por spy3
		Assert.assertEquals(spy2.getInboxSize(), 2);
		Assert.assertEquals(spy2.getPendingOutboxSize(), 0); 
		Assert.assertEquals(spy2.getOutboxSize(), 0);

	}

	@Test
	public void testSendMessagePendingStateToNormalState() {
	}

	@Test
	public void testSendMessagePendingStateToPendingState() {
	}

	@Test
	public void testSendMessagePendingStateToSilenceState() {
	}
	
	@Test
	public void testSendMessageSilenceStateToNormalState() {
		spy1.requestSilenceWith(spy2);
		spy2.acceptSilenceRequest(spy2.getSilenceRequest()); // cuando spy2 se
																// silencia con

		spy2.sendMessage(message4);// este mensaje se encola en pendingOutbox de
		// spy2 hasta desconectar cono

		Assert.assertEquals(spy2.getPendingOutboxSize(), 1); // mensaje pendiente enviado a spy3


	}
	
	@Test
	public void testSendMessageSilenceStateToPendingState() {
	}

	@Test
	public void testSendMessageSilenceStateToSilenceState() {

		spy1.requestSilenceWith(spy2);
		spy2.acceptSilenceRequest(spy2.getSilenceRequest()); // cuando spy2 se
																// silencia con

		spy2.sendMessage(message5);// este mensaje lo recibe spy1
		Assert.assertEquals(spy2.getOutboxSize(), 1); // mensaje pendiente enviado a spy1
	}

	
	@Test
	public void testSendMessageDisconnectSilence() {


		spy1.sendMessage(message1);
		spy1.requestSilenceWith(spy2);
		spy1.sendMessage(message2); // message2 deberia encolarse en
									// pendingOutbox de spy1

		spy3.sendMessage(message3); // este mensaje deberia encolarse en
		// pendinginbox de spy1 hasta que vuelva al
		// estado normal
		
		// spy2 acepta solicitud de silencio de spy1.

		spy2.acceptSilenceRequest(spy2.getSilenceRequest()); // cuando spy2 se
																// silencia con

		spy2.sendMessage(message4);// este mensaje se encola en pendingOutbox de
									// spy2 hasta desconectar cono

		spy2.sendMessage(message5);// este mensaje lo recibe spy1

		Assert.assertEquals(spy2.getPendingOutboxSize(), 1); // mensaje
																// pendiente
																// enviado a
																// spy3
		Assert.assertEquals(spy2.getOutboxSize(), 1); // mensaje pendiente
		// enviado a spy1

		spy2.disconnectSilenceRequest();

		Assert.assertEquals(spy2.getPendingOutboxSize(), 0); // recive mensaje
																// pendiente

		Assert.assertEquals(spy2.getOutboxSize(), 2); // mensaje pendiente
														// enviado a spy1

		Assert.assertEquals(spy1.getPendingOutboxSize(), 0);
		Assert.assertEquals(spy2.getPendingOutboxSize(), 0);
		Assert.assertEquals(spy3.getPendingOutboxSize(), 0);

		Assert.assertEquals(spy1.getPendingInboxSize(), 0);
		Assert.assertEquals(spy2.getPendingInboxSize(), 0);
		Assert.assertEquals(spy3.getPendingInboxSize(), 0);

		Assert.assertEquals(spy1.getOutboxSize(), 2);
		Assert.assertEquals(spy2.getOutboxSize(), 2);
		Assert.assertEquals(spy3.getOutboxSize(), 1);

		Assert.assertEquals(spy1.getInboxSize(), 2);
		Assert.assertEquals(spy2.getInboxSize(), 2);
		Assert.assertEquals(spy3.getInboxSize(), 1);

	}

}
