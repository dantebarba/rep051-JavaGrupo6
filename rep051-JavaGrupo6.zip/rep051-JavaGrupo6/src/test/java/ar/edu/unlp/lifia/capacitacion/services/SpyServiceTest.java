package ar.edu.unlp.lifia.capacitacion.services;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

public class SpyServiceTest extends AbstractServiceTest {
	
	@Autowired
	SpyService spyService;
	private Spy aSpy;
	private String username = "Carlos";
	private Spy otherSpy;
	
	@Override
	public void setUp() throws Exception {
		this.aSpy = new Spy(this.username , "12345", new Rank(Ranks.NOVICE));
		this.otherSpy = new Spy("Pablito", "12345", new Rank(Ranks.VETERAN));
	}
	
	@Test
	@Transactional
	public void testCreateSpy() {
		this.spyService.createSpy(this.username, "12345", new Rank(Ranks.NOVICE));
	}
	
	@Test(expected = Exception.class)
	@Transactional
	public void testCreateSpyWithNoUserOrPassword() {
		this.spyService.createSpy("", null, new Rank(Ranks.VETERAN));
	}
	
	@Test
	@Transactional
	public void testFindByUsername() {
		this.spyService.save(aSpy);
		Spy resultSpy = this.spyService.findByUsername(aSpy.getUsername());
		Assert.assertEquals(this.aSpy, resultSpy);
	}
	
	@Test
	@Transactional
	public void testDeleteSpy() {
		this.spyService.save(aSpy);
		this.spyService.deleteSpy(aSpy.getId());
		Assert.assertEquals(0, this.spyService.findAll().size());
	}
	
	@Test
	@Transactional
	public void testModifySpy() {
		this.spyService.save(aSpy);
		aSpy.setRole(new Role(aSpy, Roles.MOLE));
		this.spyService.modifySpy(aSpy.getId(), aSpy.getUsername(), aSpy.getPassword(), aSpy.getRank(), aSpy.getRole());
		Spy retrievedSpy = this.spyService.findById(this.aSpy.getId());
		Assert.assertEquals(aSpy.getRole(), retrievedSpy.getRole());
		
	}
	
	@Test
	@Transactional
	public void testLastestMessages() {
		IndividualMessage aMessage = new IndividualMessage(this.otherSpy, this.aSpy,
				"Hola que tal");
		aSpy.addInbox(aMessage);
		aMessage = new IndividualMessage(this.otherSpy, this.aSpy, "Chau");
		aSpy.addInbox(aMessage);
		this.spyService.save(this.aSpy);
		List<Message<?>> messages = this.spyService.getLatestMessages(aSpy.getId(), 1);
		Assert.assertEquals(1, messages.size());
		Assert.assertEquals(aMessage, messages.get(0));
	}

	@Override
	public void tearDown() throws Exception {
	}
	
	
	
	

}
