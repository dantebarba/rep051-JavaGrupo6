package ar.edu.unlp.lifia.capacitacion.dao.generic;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import ar.edu.unlp.lifia.capacitacion.JUnit4ClassRunner;

import ar.edu.unlp.lifia.capacitacion.dao.generics.GenericRepository;

@RunWith(JUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:application-context.xml" })
public abstract class AbstractDaoTest<T, D extends GenericRepository<T>> {
	
	@Autowired
	protected D dao;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	
	public abstract void setUp() throws Exception;

	@After
	public abstract void tearDown() throws Exception;

}
