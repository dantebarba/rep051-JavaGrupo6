package ar.edu.unlp.lifia.capacitacion.dao.group;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.lifia.capacitacion.dao.generic.AbstractDaoTest;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

public class GroupDaoTest extends AbstractDaoTest<Group, GroupDao> {

	@Autowired
	SpyService spyService;

	private Group group;

	@Override
	public void setUp() throws Exception {
		Spy spy = new Spy("user", "pass", Rank.getVeteran());
		spyService.save(spy);

		group = new Group(spy, "name", "description");
	}

	@Override
	public void tearDown() throws Exception {
		dao.delete(group);
	}

	@Test
	@Transactional
	public void testSendMessageNormalStateToNormalState() {

		Long id = (Long) dao.save(group);

		Group groupPersisted = dao.findById(id);

		assertEquals(groupPersisted, group);
		assertEquals(groupPersisted.getName(), group.getName());
		assertEquals(groupPersisted.getDescription(), group.getDescription());
	}

}
