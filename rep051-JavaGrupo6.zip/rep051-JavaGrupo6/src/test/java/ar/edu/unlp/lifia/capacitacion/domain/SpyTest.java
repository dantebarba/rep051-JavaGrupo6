package ar.edu.unlp.lifia.capacitacion.domain;

import org.junit.Before;
import org.junit.Test;

import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class SpyTest {
	
	private Spy aSpy;

	@Before
	public void setUp() {
		this.aSpy = new Spy("Carlos", "1234", new Rank(Ranks.NOVICE));
		
	}
	
	@Test
	public void testMessageAccess() {
		this.aSpy.getOutbox();
	}

}
