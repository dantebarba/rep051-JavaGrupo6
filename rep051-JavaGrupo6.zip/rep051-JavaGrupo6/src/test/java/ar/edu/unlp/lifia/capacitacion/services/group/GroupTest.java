package ar.edu.unlp.lifia.capacitacion.services.group;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.lifia.capacitacion.dao.group.GroupDao;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.AbstractServiceTest;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

public class GroupTest extends AbstractServiceTest {

	@Autowired
	GroupDao dao;

	@Autowired
	GroupService groupService;

	@Autowired
	SpyService spyService;

	private Spy spy;

	@Before
	public void setUp() {
		// SUPUESTAMENTE, NECESITO HACER ESTO PORQUE NO HAY SESIONES AUN, Y
		// OBTIENE EL PRIMER ESPIA
		spy = new Spy("username", "password", Rank.getVeteran());
		spyService.save(spy);
		spy = spyService.findByUsername(spy.getUsername()); 
	}

	@Test
	@Transactional
	public void testCreateGroup() {
		// Group group = new Group(spy, "Name", "Descripcion");
		// El usuario de la sesion, deberia ser veterano.
		Group group = groupService.createGroup("Name", "description", spy.getId());

		assertEquals(dao.findById(group.id), group);
	}

	@Test
	@Transactional
	public void testAddSpy() {
		// Refactor: ASUMO que funciona la persistencia de un spy.
		Spy aSpy = new Spy("username2", "password2", Rank.getVeteran());
		Spy anotherSpy = new Spy("username3", "password3", Rank.getVeteran());
		spyService.save(aSpy);
		spyService.save(anotherSpy);

		Group group = groupService.createGroup("Name", "description", spy.getId());

		assertTrue(groupService.addSpy(group.id, aSpy.id, Roles.BOSS));

		group = dao.findById(group.id);
		assertTrue(group.containsSpy(aSpy));

		assertFalse(group.containsSpy(anotherSpy));

	}

	@Test
	@Transactional
	public void testDeleteSpyFrom() {
		Group group = groupService.createGroup("Name", "Description", spy.getId());
		
		Spy aSpy = new Spy("username2", "password2", Rank.getNovice());
		
		spyService.save(aSpy);
		
		groupService.addSpy(group.id, aSpy.id, Roles.MOLE);
		
		assertTrue(groupService.findById(group.id).containsSpy(aSpy));

		assertTrue(groupService.deleteSpyFrom(group.id, aSpy.id));

		assertFalse(groupService.findById(group.id).containsSpy(aSpy));
		
		assertTrue(groupService.findById(group.id).containsSpy(spy));
	}

	@Test
	@Transactional
	public void testDeleteGroup() {
		Group group = groupService.createGroup("Name", "Description", spy.getId());

		assertTrue(groupService.deleteGroup(group.id));
	}

	@Override
	public void tearDown() throws Exception {
	}

}
