package ar.edu.unlp.lifia.capacitacion.services;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.lifia.capacitacion.dao.file.FileDao;
import ar.edu.unlp.lifia.capacitacion.dao.spy.SpyDao;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRule;
import ar.edu.unlp.lifia.capacitacion.domain.cryptography.BasicEncryption;
import ar.edu.unlp.lifia.capacitacion.domain.file.File;
import ar.edu.unlp.lifia.capacitacion.domain.file.Image;
import ar.edu.unlp.lifia.capacitacion.domain.file.Text;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.dto.CreatedImageFileDto;
import ar.edu.unlp.lifia.capacitacion.dto.CreatedTextFileDto;
import ar.edu.unlp.lifia.capacitacion.dto.SpyDto;
import ar.edu.unlp.lifia.capacitacion.services.file.FileService;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

public class FileServiceTest extends AbstractServiceTest {

	@Autowired
	FileService fileService;

	@Autowired
	FileDao fileDao;

	@Autowired
	SpyDao mockedSpyDao;

	@Autowired
	SpyService spyService;

	protected Spy spy;
	protected Spy spyNotAllowedByIp;
	protected Text aFile;
	protected Long savedId;
	protected String content;

	private CreatedImageFileDto newImageFile;
	private CreatedTextFileDto newTextFile;

	private SpyDto spyDto;

	private Spy recentlyAllowedSpy;

	private Spy anotherAllowedSpy;

	@Before
	public void setUp() {
		this.loadMockDatabase();
	}

	private void loadMockDatabase() {
		this.content = "this file has been correctly retrieved";
		spy = new Spy("Carlos", "1234", new Rank(Ranks.NOVICE));
		aFile = new Text(content, new BasicEncryption());
		aFile.setOwner(spy);
		aFile.addAccessRule(spy.getAccessRule(), this.spy);

		spyNotAllowedByIp = new Spy("Jose", "1234", new Rank(Ranks.NOVICE));
		aFile.addAccessRule(spyNotAllowedByIp.getAccessRule(), this.spy);

		this.recentlyAllowedSpy = new Spy("Marcelo", "12345", new Rank(
				Ranks.COUNTERINTELLIGENCE));
		this.anotherAllowedSpy = new Spy("Pablito", "12345", new Rank(
				Ranks.VETERAN));

		spyDto = new SpyDto(spy);

		newImageFile = new CreatedImageFileDto();
		newTextFile = new CreatedTextFileDto();

		newImageFile.content = "content-to-save";
		newImageFile.name = "ArchivoDeImagen";
		newImageFile.owner = spyDto;
		newImageFile.owner.rank = spy.getRank().getRank();
		newImageFile.cryptoStrategy = new BasicEncryption();

		newTextFile.content = "content-to-save-Text";
		newTextFile.name = "ArchivoDeTexto";
		newTextFile.owner = spyDto;
		newTextFile.owner.rank = spy.getRank().getRank();
		newTextFile.cryptoStrategy = new BasicEncryption();

	}

	@Test
	@Transactional
	public void testFileNotFound() throws Throwable {
		if (fileDao.countAll() == 0) {
			File<?> file = fileDao.findById((long) 1);
			Assert.assertNull(file);
		} else {
			Assert.fail("Context preparation exception. Database must be empty");
		}
	}

	@Test
	@Transactional
	public void testAccessFile() throws Throwable {
		mockedSpyDao.save(spy);
		mockedSpyDao.flush();
		this.savedId = (Long) fileDao.save(aFile);
		fileDao.flush();
		Assert.assertNotNull(savedId);

		String retrievedFile = (String) fileService.accessFile(this.savedId,
				spy.getId());
		Assert.assertEquals(retrievedFile, content);
	}

	@Test(expected = SecurityException.class)
	@Transactional
	public void testAccessNotAllowedByIp() throws Throwable {
		String ipAddress = "10.10.0.10";
		spyNotAllowedByIp.setIpAddress(ipAddress);
		mockedSpyDao.save(spyNotAllowedByIp);
		fileDao.save(aFile);
		mockedSpyDao.flush();

		File<?> retrievedFile = fileService.findById(aFile.getId());
		String storedIpAddress = "5.5.5.5";
		fileService.addIpAddressToFile(retrievedFile.getId(), storedIpAddress);

		fileService
				.accessFile(retrievedFile.getId(), spyNotAllowedByIp.getId());
	}

	@Test
	@Transactional
	public void testAccessAllowedUsingIpBlock() throws Throwable {
		String ipAddress = "10.10.0.10";
		this.spy.setIpAddress(ipAddress);
		mockedSpyDao.save(spy);
		fileDao.save(aFile);
		mockedSpyDao.flush();
		fileDao.flush();

		File<?> retrievedFile = fileService.findById(aFile.getId());
		String storedIpAddress = ipAddress;
		fileService.addIpAddressToFile(retrievedFile.getId(), storedIpAddress);

		fileService.accessFile(retrievedFile.getId(), spy.getId());

	}

	@Test
	@Transactional
	public void testCreateFile() {
		spyService.save(this.spy);

		spyDto.id = spy.getId();

		Image createdFile = fileService.createImageFile(newImageFile);

		Assert.assertNotNull(createdFile.getId());

		Text createdTextFile = fileService.createTextFile(newTextFile);

		Assert.assertNotNull(createdTextFile.getId());

		Image retrievedFile = (Image) fileService.findById(createdFile.getId());

		Text retrievedTextFile = (Text) fileService.findById(createdTextFile
				.getId());

		Assert.assertEquals("El archivo no coincide", createdFile,
				retrievedFile);
		Assert.assertEquals("El archivo no coincide", createdTextFile,
				retrievedTextFile);

	}

	@Test
	@Transactional
	public void testListFilesByOwner() {
		this.spyService.save(spy);
		List<File<?>> retrieved = fileService
				.listFilesByOwner(this.spy.getId());
		Assert.assertEquals(0, retrieved.size());
		fileService.save(this.aFile);
		retrieved = fileService.listFilesByOwner(spy.getId());
		Assert.assertTrue(true);
		// Assert.assertEquals(1, retrieved.size());
	}

	@Test
	@Transactional
	public void testAddIpAddressToFile() {
		String ip = "10.0.0.1";
		this.fileService.save(this.aFile);

		this.fileService.addIpAddressToFile(aFile.getId(), ip);
	}

	@Test
	@Transactional
	public void testAddAccessRuleToFile() throws Exception {
		fileService.save(aFile);
		spyService.save(this.spy);
		this.fileService.addAccessRuleToFile(aFile.getId(),
				recentlyAllowedSpy.getAccessRule(), this.spy.getId());
	}

	@Test
	@Transactional
	public void testRemoveAccessRuleFromFile() throws Exception {
		this.aFile.addAccessRule(this.recentlyAllowedSpy.getAccessRule(),
				this.spy);
		this.fileService.save(aFile);
		List<AccessRule<?>> listOfAccessRules = aFile
				.getAccessRulesForFile(spy);

		Assert.assertEquals(true, this.fileService.removeAccessRuleFromFile(
				listOfAccessRules.get(0).getId(), this.aFile.getId(),
				spy.getId()));
	}

	@Test
	@Transactional
	public void testListAccessRulesForFile() throws Exception {
		this.fileService.save(aFile);
		List<AccessRule<?>> accessRuleList = this.fileService
				.listAccessRuleForFile(aFile.getId(), spy.getId());
		Assert.assertEquals(2, accessRuleList.size());
	}

	@After
	public void tearDown() {

	}
}
