package ar.edu.unlp.lifia.capacitacion.domain.Spy;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class GroupTest {

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	private static Spy veteranSpy;

	private static Spy Spy2;
	private static Spy Spy1;

	private ar.edu.unlp.lifia.capacitacion.domain.spy.Group group;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		veteranSpy = new Spy("Name", "Password", new Rank(Ranks.VETERAN));
		Spy1 = new Spy("Name", "password", new Rank(Ranks.COUNTERINTELLIGENCE));
		Spy2 = new Spy("Name", "password", new Rank(Ranks.NOVICE));
		/*QUien deberia hacer esto ?*/
		Spy1.setId(1L);
		Spy2.setId(2L);
		veteranSpy.setId(3L);
		
		veteranSpy.setRole(new Role(veteranSpy, Roles.BOSS));
		Spy1.setRole(new Role(Spy1, Roles.MOLE));
		Spy2.setRole(new Role(Spy2, Roles.PRIVATE));
	}

	@Before
	public void setUp() throws Exception {

	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		group = null;
	}

	/*
	 * Crear Grupo con usuario veterano no deberia dar exception ni error
	 */
	@Test
	public void GroupCreationWithVeteranSpy() {
		try {
			group = new ar.edu.unlp.lifia.capacitacion.domain.spy.Group(
					veteranSpy, "Group", "GroupDescription");
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	/*
	 * Crear un usuario con rango veterano, deberia ser responsabilidad del
	 * ServiceGroup y no del Group del Dominio.
	 */
	@Test
	public void GroupCreationWithOtherSpy() throws Exception {
		thrown.expect(Exception.class);

		group = new ar.edu.unlp.lifia.capacitacion.domain.spy.Group(Spy1,
				"Group", "GroupDescription");
	}

	/**
	 * Test method for
	 * {@link ar.edu.unlp.lifia.capacitacion.domain.spy.Group#deleteSpy(ar.edu.unlp.lifia.capacitacion.domain.spy.Spy)}
	 * .
	 */
	@Test
	public void testDeleteSpy() {
		try {
			group = new ar.edu.unlp.lifia.capacitacion.domain.spy.Group(
					veteranSpy, "Group", "GroupDescription");
		} catch (Exception e) {
			fail(e.getMessage());
		}

		group.addSpy(Spy1, Roles.MOLE);
		Assert.assertTrue(group.containsSpy(Spy1));
		Assert.assertTrue(group.deleteSpy(Spy1));
		Assert.assertFalse(group.deleteSpy(Spy1));
		//Assert.assertFalse(group.deleteSpy(Spy1));
		//Assert.assertFalse(group.deleteSpy(Spy2));
	}

	/**
	 * Testeo que agregar un espia funciona
	 * 
	 * */
	@Test
	public void testAddSpy() {
		try {
			group = new ar.edu.unlp.lifia.capacitacion.domain.spy.Group(
					veteranSpy, "Group", "GroupDescription");
		} catch (Exception e) {
			fail(e.getMessage());
		}
		Assert.assertFalse(group.containsSpy(Spy1));
		Assert.assertFalse(group.containsSpy(Spy2));

		group.addSpy(Spy1, Roles.MOLE);
		Assert.assertTrue(group.containsSpy(Spy1));

		group.addSpy(Spy2, Roles.PRIVATE);
		Assert.assertTrue(group.containsSpy(Spy2));
		Assert.assertTrue(group.containsSpy(Spy1));
	}

	/**
	 * No puedo agregar 2 espias, ni con el mismo rol ni distinto
	 */
	@Test
	public void testRepeatSpy() {
		try {
			group = new ar.edu.unlp.lifia.capacitacion.domain.spy.Group(
					veteranSpy, "Group", "GroupDescription");
		} catch (Exception e) {
			fail(e.getMessage());
		}
		Assert.assertTrue(group.addSpy(Spy1, Roles.MOLE));
		Assert.assertFalse(group.addSpy(Spy1, Roles.PRIVATE));
	}

}
