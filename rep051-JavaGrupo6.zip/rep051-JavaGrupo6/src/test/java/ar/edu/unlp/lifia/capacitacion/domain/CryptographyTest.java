package ar.edu.unlp.lifia.capacitacion.domain;

import java.lang.reflect.Field;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ar.edu.unlp.lifia.capacitacion.domain.cryptography.AdvancedEncryption;
import ar.edu.unlp.lifia.capacitacion.domain.cryptography.BasicEncryption;

public class CryptographyTest {
	
	private BasicEncryption basicAlgo;
	private AdvancedEncryption advAlgo;
	private String stringToTest;

	/**
	 * Habilita las librerias requeridas para encryptacion.
	 * @see http://suhothayan.blogspot.com.ar/2012/05/how-to-install-java-cryptography.html
	 */
	public static void enableJCE() {
		try { 
			Field field = Class.forName("javax.crypto.JceSecurity").
			getDeclaredField("isRestricted");
			field.setAccessible(true);
			field.set(null, java.lang.Boolean.FALSE); 
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	@Before
	public void setUp() {
		
		CryptographyTest.enableJCE();
		
		this.stringToTest = "HolaMundo";
		this.advAlgo = new AdvancedEncryption("hola");
		this.basicAlgo = new BasicEncryption("hola");
	}
	
	@Test
	public void testAdvancedEncryptation() {
		
		String result = advAlgo.encrypt(this.stringToTest);
		Assert.assertEquals((result != stringToTest), true);
		result = advAlgo.decrypt(result);
		Assert.assertEquals(result, stringToTest);
	}
	
	@Test
	public void testBasicEncryptation() {
		
		String result = basicAlgo.encrypt(this.stringToTest);
		Assert.assertEquals((result != stringToTest), true);
		result = basicAlgo.decrypt(result);
		Assert.assertEquals(result, stringToTest);
		
	}
	
}
