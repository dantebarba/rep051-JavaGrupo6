package ar.edu.unlp.lifia.capacitacion.services;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;
import ar.edu.unlp.lifia.capacitacion.services.message.MessageService;
import ar.edu.unlp.lifia.capacitacion.services.spy.SpyService;

public class IndividualMessageTest extends AbstractServiceTest {
	
	@Autowired
	SpyService spyService;
	@Autowired
	MessageService messageService;
	
	private Spy spy1;
	private Spy spy2;
	private IndividualMessage message;
	
	@Override
	public void setUp() throws Exception {
		this.spy1 = new Spy("Carlos" , "12345", new Rank(Ranks.NOVICE));
		this.spy2 = new Spy("Juan", "12345", new Rank(Ranks.VETERAN));
		spy1 = this.spyService.createSpy(spy1.getUsername(), spy1.getPassword(), spy1.getRank());
		spy2 = this.spyService.createSpy(spy2.getUsername(), spy2.getPassword(), spy2.getRank());
		this.message = new IndividualMessage(spy1, spy2, "Hola");		
	}
	
	@Test
	@Transactional
	public void testSendIndividualMessage() {
		IndividualMessage result = this.messageService.sendIndividualMessage(message.getSender().getId(), message.getReceiver().getId(), message.getContent());
		Assert.assertEquals(this.messageService.findById(result.getId()), result);
	}
	
	@Override
	public void tearDown() throws Exception {
	}
	
	
	
	

}
