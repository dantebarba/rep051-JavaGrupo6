package ar.edu.unlp.lifia.capacitacion.domain;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ar.edu.unlp.lifia.capacitacion.domain.message.GroupMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.IndividualMessage;
import ar.edu.unlp.lifia.capacitacion.domain.message.Message;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class GroupMessageTest {
	private Spy spy1;
	private Spy spy2;
	private Spy spy3;
	private Message<Group> groupMessage1;
	private Message<Group> groupMessage2;
	private Message<Spy> message2;
	private Message<Spy> message3;
	private Message<Spy> message4;
	private Message<Spy> message5;
	private Group group;

	@Before
	public void setUp() throws Exception {
		spy1 = new Spy("User1", "1234", new Rank(Ranks.VETERAN));
		spy2 = new Spy("User2", "1234", new Rank(Ranks.NOVICE));
		spy3 = new Spy("User3", "user3", new Rank(Ranks.NOVICE));
		
		group = new Group(spy1, "grupo1", "description");
		group.addSpy(spy2, Roles.MOLE);
		group.addSpy(spy3, Roles.MOLE);
		groupMessage1 = new GroupMessage(spy1, group, "mensaje grupal 1");
		groupMessage2 = new GroupMessage(spy1, group, "mensaje grupal 2");
		message2 = new IndividualMessage(spy1, spy2, "Mensaje 2");
		message3 = new IndividualMessage(spy3, spy1, "Mensaje 3");
		message4 = new IndividualMessage(spy2, spy3, "Mensaje 4");
		message5 = new IndividualMessage(spy2, spy1, "Mensaje 5 silencioso");
	}


	@Test
	public void testSendMessageNormalStateToNormalState() {
		// spy1 envia mensaje a spy2. Ambos en estado normal
		spy1.sendMessage(groupMessage1);
		Assert.assertEquals(spy1.getOutboxSize(), 1); 
		Assert.assertEquals(spy2.getOutboxSize(), 0);
		Assert.assertEquals(spy3.getOutboxSize(), 0);
		Assert.assertEquals(spy1.getInboxSize(), 1);
		Assert.assertEquals(spy2.getInboxSize(), 1); 
		Assert.assertEquals(spy3.getInboxSize(), 1); 
		Assert.assertEquals(spy2.getOutboxSize(), 0);
		
	}
	
	@Test
	public void testSendMessageNormalStateToPendingState() {
		// spy1 envia solicitud de silencio a spy2. spy3 envia mensaje a spy2,
		// que esta como pendiente

		spy1.requestSilenceWith(spy2);

		spy1.sendMessage(groupMessage1); // message2 deberia encolarse en
									// pendingOutbox de spy1
		Assert.assertEquals(spy1.getOutboxSize(), 0);
		Assert.assertEquals(spy1.getPendingOutboxSize(), 1);
		Assert.assertEquals(spy1.getPendingInboxSize(), 0);

		Assert.assertEquals(spy2.getOutboxSize(), 0);
		Assert.assertEquals(spy2.getPendingOutboxSize(), 0);
		Assert.assertEquals(spy2.getPendingInboxSize(), 0);
		Assert.assertEquals(spy2.getInboxSize(), 0);

		
		spy3.sendMessage(groupMessage2); // este mensaje deberia encolarse en
									// pendinginbox de spy1 hasta que vuelva al
									// estado normal

		Assert.assertEquals(spy1.getPendingInboxSize(), 1);
		Assert.assertEquals(spy3.getOutboxSize(), 1);

	}

	@Test
	public void testSendMessageNormalStateToSilenceState() {
		spy1.sendMessage(groupMessage1);
		spy1.requestSilenceWith(spy2);
		spy1.sendMessage(message2); // message2 deberia encolarse en
									// pendingOutbox de spy1


		spy3.sendMessage(message3); // este mensaje deberia encolarse en
		// pendinginbox de spy1 hasta que vuelva al
		// estado normal

		// spy2 acepta solicitud de silencio de spy1.

		spy2.acceptSilenceRequest(spy2.getSilenceRequest()); // cuando spy2 se
																// silencia con
																// spy1, spy2
																// recibe el
																// mensaje de
																// spy1 que este
																// tenia
																// encolado

		Assert.assertEquals(spy1.getPendingOutboxSize(), 0); // cola vacia.
																// Mensaje
																// enviado a
																// spy2
		Assert.assertEquals(spy1.getPendingInboxSize(), 1); // mensaje pendiente
															// enviado por spy3
		Assert.assertEquals(spy2.getInboxSize(), 2);
		Assert.assertEquals(spy2.getPendingOutboxSize(), 0); 
		Assert.assertEquals(spy2.getOutboxSize(), 0);

	}

	@Test
	public void testSendMessagePendingStateToNormalState() {
	}

	@Test
	public void testSendMessagePendingStateToPendingState() {
	}

	@Test
	public void testSendMessagePendingStateToSilenceState() {
	}
	
	@Test
	public void testSendMessageSilenceStateToNormalState() {
		spy1.requestSilenceWith(spy2);
		spy2.acceptSilenceRequest(spy2.getSilenceRequest()); // cuando spy2 se
																// silencia con

		spy2.sendMessage(message4);// este mensaje se encola en pendingOutbox de
		// spy2 hasta desconectar cono

		Assert.assertEquals(spy2.getPendingOutboxSize(), 1); // mensaje pendiente enviado a spy3


	}
	
	@Test
	public void testSendMessageSilenceStateToPendingState() {
	}

	@Test
	public void testSendMessageSilenceStateToSilenceState() {

		spy1.requestSilenceWith(spy2);
		spy2.acceptSilenceRequest(spy2.getSilenceRequest()); // cuando spy2 se
																// silencia con

		spy2.sendMessage(message5);// este mensaje lo recibe spy1
		Assert.assertEquals(spy2.getOutboxSize(), 1); // mensaje pendiente enviado a spy1
	}

	
	@Test
	public void testSendMessageDisconnectSilence() {


		spy1.sendMessage(groupMessage1);
		spy1.requestSilenceWith(spy2);
		spy1.sendMessage(message2); // message2 deberia encolarse en
									// pendingOutbox de spy1

		spy3.sendMessage(message3); // este mensaje deberia encolarse en
		// pendinginbox de spy1 hasta que vuelva al
		// estado normal
		
		// spy2 acepta solicitud de silencio de spy1.

		spy2.acceptSilenceRequest(spy2.getSilenceRequest()); // cuando spy2 se
																// silencia con

		spy2.sendMessage(message4);// este mensaje se encola en pendingOutbox de
									// spy2 hasta desconectar cono

		spy2.sendMessage(message5);// este mensaje lo recibe spy1

		Assert.assertEquals(spy2.getPendingOutboxSize(), 1); // mensaje
																// pendiente
																// enviado a
																// spy3
		Assert.assertEquals(spy2.getOutboxSize(), 1); // mensaje pendiente
		// enviado a spy1

		spy2.disconnectSilenceRequest();

		Assert.assertEquals(spy2.getPendingOutboxSize(), 0); // recive mensaje
																// pendiente

		Assert.assertEquals(spy2.getOutboxSize(), 2); // mensaje pendiente
														// enviado a spy1

		Assert.assertEquals(spy1.getPendingOutboxSize(), 0);
		Assert.assertEquals(spy2.getPendingOutboxSize(), 0);
		Assert.assertEquals(spy3.getPendingOutboxSize(), 0);

		Assert.assertEquals(spy1.getPendingInboxSize(), 0);
		Assert.assertEquals(spy2.getPendingInboxSize(), 0);
		Assert.assertEquals(spy3.getPendingInboxSize(), 0);

		Assert.assertEquals(spy1.getOutboxSize(), 2);
		Assert.assertEquals(spy2.getOutboxSize(), 2);
		Assert.assertEquals(spy3.getOutboxSize(), 1);

		Assert.assertEquals(spy1.getInboxSize(), 3);
		Assert.assertEquals(spy2.getInboxSize(), 2);
		Assert.assertEquals(spy3.getInboxSize(), 2);

	}

}
