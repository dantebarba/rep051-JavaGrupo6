package ar.edu.unlp.lifia.capacitacion.domain;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleGroup;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleIndividual;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleRank;
import ar.edu.unlp.lifia.capacitacion.domain.accessRule.AccessRuleRole;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Rank;
import ar.edu.unlp.lifia.capacitacion.domain.rank.Ranks;
import ar.edu.unlp.lifia.capacitacion.domain.role.Role;
import ar.edu.unlp.lifia.capacitacion.domain.role.Roles;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Group;
import ar.edu.unlp.lifia.capacitacion.domain.spy.Spy;

public class AccessRuleTest {
	
	private AccessRuleIndividual accessRuleIndividual;
	private AccessRuleGroup accessRuleGroup;
	private AccessRuleRole accessRuleRole;
	private AccessRuleRank accessRuleRank;
	private Spy aSpy = new Spy("Carlos", "1234", new Rank(Ranks.NOVICE));
	private Group aGroup = new Group(aSpy, "GrupoCarlos", "El grupo de carlos");
	private Role aRole = aGroup.getBoss();
	private Rank aRank = new Rank(Ranks.NOVICE);

	@Before
	public void setUp() {
		// TODO dbarba refactor to AccessRuleFactory?
		
		this.accessRuleIndividual = aSpy.getAccessRule();
		this.accessRuleGroup = aGroup.getAccessRule();
		this.accessRuleRole = aRole.getAccessRule();
		this.accessRuleRank = aRank.getAccessRule();
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void allowAccess() {
		Assert.assertEquals(true, this.accessRuleIndividual.validateAgainst(aSpy));
		Assert.assertEquals(true, this.accessRuleGroup.validateAgainst(aSpy));
		Assert.assertEquals(true, this.accessRuleRank.validateAgainst(aSpy));
		Assert.assertEquals(true, this.accessRuleRole.validateAgainst(aSpy));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void denyAccess() {
		Assert.assertEquals(false, this.accessRuleIndividual.validateAgainst(new Spy()));	
		Assert.assertEquals(false, this.accessRuleGroup.validateAgainst(new Spy()));
		this.aSpy.setRank(new Rank(Ranks.VETERAN));
		Assert.assertEquals(false, this.accessRuleRank.validateAgainst(this.aSpy));
		this.aSpy.setRole(new Role(this.aSpy, Roles.MOLE));
		Assert.assertEquals(false, this.accessRuleRole.validateAgainst(this.aSpy));
	}

}
